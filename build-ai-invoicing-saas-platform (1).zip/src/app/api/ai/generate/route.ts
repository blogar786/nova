import { NextRequest, NextResponse } from "next/server";

// Mock AI response - in production, this would call OpenAI API
const mockAIResponse = {
  business: {
    name: "TechCorp Solutions",
    email: "contact@techcorp.com",
    phone: "+1 (555) 123-4567",
    address: "123 Tech Street, San Francisco, CA 94105",
    website: "www.techcorp.com",
    taxNumber: "TX-987654321",
    vatNumber: "VAT-123456789",
  },
  customer: {
    name: "Ahmed Trading Dubai",
    email: "ahmed@tradingdubai.com",
    phone: "+971 4 123 4567",
    address: "Dubai Internet City, Dubai, UAE",
  },
  items: [
    { description: "Posture Belts - 10 units", quantity: 10, unitPrice: 25.0, taxRate: 5, taxAmount: 12.5, discount: 0, total: 262.5 },
  ],
  invoiceInfo: {
    invoiceNumber: "INV-2024-0013",
    currency: "USD",
    country: "AE",
    taxType: "VAT",
    taxRate: 5,
    paymentTerms: "NET_30",
    notes: "Thank you for your business! Payment due within 30 days.",
    terms: "All sales are final. Payment is due within 30 days of invoice date.",
  },
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt } = body;

    if (!prompt || typeof prompt !== "string") {
      return NextResponse.json(
        { error: "Prompt is required" },
        { status: 400 }
      );
    }

    // Check if OpenAI API key is available
    const apiKey = process.env.OPENAI_API_KEY;

    if (apiKey) {
      try {
        const { OpenAI } = await import("openai");
        const openai = new OpenAI({ apiKey });

        const response = await openai.chat.completions.create({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content: `You are an AI invoice generation assistant. Parse the user's prompt and extract:
- Business information (name, email, phone, address, website, tax/VAT/GST numbers)
- Customer information (name, email, phone, address)
- Invoice items (description, quantity, unit price, tax rate)
- Invoice details (currency, country, tax type, tax rate, payment terms, notes, terms)

Return ONLY valid JSON with this structure:
{
  "business": { "name": "", "email": "", "phone": "", "address": "", "website": "", "taxNumber": "", "vatNumber": "", "gstNumber": "" },
  "customer": { "name": "", "email": "", "phone": "", "address": "" },
  "items": [{ "description": "", "quantity": 1, "unitPrice": 0, "taxRate": 0 }],
  "invoiceInfo": { "invoiceNumber": "", "currency": "USD", "country": "US", "taxType": "VAT", "taxRate": 0, "paymentTerms": "NET_30", "notes": "", "terms": "" }
}

If information is not provided, use empty strings or sensible defaults.`,
            },
            {
              role: "user",
              content: prompt,
            },
          ],
          max_tokens: 2000,
          temperature: 0.3,
        });

        const content = response.choices[0]?.message?.content;
        if (content) {
          try {
            const parsed = JSON.parse(content);
            return NextResponse.json({ success: true, ...parsed });
          } catch {
            // Fall through to mock response
          }
        }
      } catch (error) {
        console.error("OpenAI API error:", error);
        // Fall through to mock response
      }
    }

    // Mock response for demo
    return NextResponse.json({
      success: true,
      ...mockAIResponse,
      isMock: !apiKey,
    });
  } catch (error) {
    console.error("AI generation error:", error);
    return NextResponse.json(
      { error: "Failed to generate invoice" },
      { status: 500 }
    );
  }
}
