import { NextRequest, NextResponse } from "next/server";
import { AIError } from "@/lib/types";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { business, customer, items, invoiceInfo, fieldConfig } = body;

    const errors: AIError[] = [];

    // Check for missing customer details
    if (!customer?.name || customer.name.trim() === "") {
      errors.push({
        type: "missing",
        severity: "high",
        field: "Customer Name",
        message: "Customer name is required",
        suggestion: "Enter the customer's full name",
      });
    }

    if (!customer?.email || customer.email.trim() === "") {
      errors.push({
        type: "missing",
        severity: "medium",
        field: "Customer Email",
        message: "Customer email is missing",
        suggestion: "Add the customer's email address for payment notifications",
      });
    }

    if (!customer?.address || customer.address.trim() === "") {
      errors.push({
        type: "missing",
        severity: "medium",
        field: "Customer Address",
        message: "Customer address is missing",
        suggestion: "Add the customer's billing address",
      });
    }

    // Check for missing business details
    if (!business?.name || business.name.trim() === "") {
      errors.push({
        type: "missing",
        severity: "high",
        field: "Business Name",
        message: "Your business name is required",
        suggestion: "Enter your company name",
      });
    }

    // Check invoice items
    if (items && items.length > 0) {
      items.forEach((item: any, index: number) => {
        if (!item.description || item.description.trim() === "") {
          errors.push({
            type: "missing",
            severity: "medium",
            field: `Item ${index + 1}`,
            message: "Item description is missing",
            suggestion: `Add a description for item ${index + 1}`,
          });
        }
        if (!item.quantity || item.quantity <= 0) {
          errors.push({
            type: "invalid",
            severity: "high",
            field: `Item ${index + 1} Quantity`,
            message: "Quantity must be greater than 0",
            suggestion: "Enter a valid quantity",
          });
        }
        if (!item.unitPrice || item.unitPrice <= 0) {
          errors.push({
            type: "invalid",
            severity: "high",
            field: `Item ${index + 1} Price`,
            message: "Unit price must be greater than 0",
            suggestion: "Enter a valid unit price",
          });
        }
      });

      // Check for duplicate items
      const descriptions = items.map((i: any) => i.description?.toLowerCase()).filter(Boolean);
      const duplicates = descriptions.filter((desc: string, i: number) => descriptions.indexOf(desc) !== i);
      if (duplicates.length > 0) {
        errors.push({
          type: "duplicate",
          severity: "low",
          field: "Invoice Items",
          message: "Duplicate product descriptions detected",
          suggestion: "Review and consolidate duplicate items",
        });
      }
    } else {
      errors.push({
        type: "missing",
        severity: "high",
        field: "Invoice Items",
        message: "No invoice items found",
        suggestion: "Add at least one product or service",
      });
    }

    // Check tax
    if (invoiceInfo?.taxRate > 0 && !invoiceInfo?.taxType) {
      errors.push({
        type: "invalid",
        severity: "medium",
        field: "Tax Type",
        message: "Tax rate is set but tax type is missing",
        suggestion: "Select a tax type (VAT, GST, Sales Tax, etc.)",
      });
    }

    // Check for missing VAT when required
    const country = invoiceInfo?.country;
    const euCountries = ["GB", "DE", "FR", "IT", "ES", "NL", "BE", "AT", "PT", "GR", "IE", "PL", "SE", "DK", "FI", "NO"];
    if (country && euCountries.includes(country) && !business?.vatNumber) {
      errors.push({
        type: "missing",
        severity: "high",
        field: "VAT Number",
        message: "VAT number is required for EU businesses",
        suggestion: "Add your VAT registration number",
      });
    }

    // Check payment information
    if (!invoiceInfo?.paymentTerms) {
      errors.push({
        type: "missing",
        severity: "medium",
        field: "Payment Terms",
        message: "Payment terms are not specified",
        suggestion: "Set payment terms (e.g., NET_30)",
      });
    }

    // Check for missing due date
    if (!invoiceInfo?.dueDate) {
      errors.push({
        type: "missing",
        severity: "medium",
        field: "Due Date",
        message: "Due date is missing",
        suggestion: "Set a payment due date",
      });
    }

    // Check for missing invoice number
    if (!invoiceInfo?.invoiceNumber) {
      errors.push({
        type: "missing",
        severity: "high",
        field: "Invoice Number",
        message: "Invoice number is missing",
        suggestion: "Generate or enter an invoice number",
      });
    }

    // Check calculations
    if (items && items.length > 0) {
      let calculatedSubtotal = 0;
      items.forEach((item: any, idx: number) => {
        const itemTotal = (item.quantity || 0) * (item.unitPrice || 0) - (item.discount || 0);
        const itemTax = itemTotal * ((item.taxRate || 0) / 100);
        const expectedTotal = itemTotal + itemTax;

        if (Math.abs(expectedTotal - (item.total || 0)) > 0.01) {
          errors.push({
            type: "calculation",
            severity: "high",
            field: `Item ${idx + 1} Total`,
            message: `Calculated total (${expectedTotal.toFixed(2)}) doesn't match entered total (${item.total})`,
            suggestion: "Verify the calculation or let AI recalculate",
          });
        }
        calculatedSubtotal += expectedTotal;
      });

      // Check invoice total
      const taxAmount = calculatedSubtotal * ((invoiceInfo?.taxRate || 0) / 100);
      const expectedInvoiceTotal = calculatedSubtotal + taxAmount + (invoiceInfo?.shippingAmount || 0) - (invoiceInfo?.discountAmount || 0);

      if (invoiceInfo?.totalAmount && Math.abs(expectedInvoiceTotal - invoiceInfo.totalAmount) > 0.01) {
        errors.push({
          type: "calculation",
          severity: "high",
          field: "Invoice Total",
          message: "Invoice total calculation is incorrect",
          suggestion: "Verify subtotal, tax, discount, and shipping calculations",
        });
      }
    }

    // Check for missing mandatory legal information
    if (country && !business?.taxNumber && !business?.vatNumber && !business?.gstNumber) {
      errors.push({
        type: "legal",
        severity: "medium",
        field: "Tax Registration",
        message: "No tax registration number found",
        suggestion: "Add a tax/VAT/GST number for legal compliance",
      });
    }

    // Check currency
    if (!invoiceInfo?.currency) {
      errors.push({
        type: "missing",
        severity: "low",
        field: "Currency",
        message: "Currency is not specified",
        suggestion: "Select a currency for the invoice",
      });
    }

    return NextResponse.json({
      success: true,
      errors,
      summary: {
        total: errors.length,
        high: errors.filter((e) => e.severity === "high").length,
        medium: errors.filter((e) => e.severity === "medium").length,
        low: errors.filter((e) => e.severity === "low").length,
      },
    });
  } catch (error) {
    console.error("Error detection error:", error);
    return NextResponse.json(
      { error: "Failed to detect errors" },
      { status: 500 }
    );
  }
}
