import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { templates } from "@/db/schema";
import { eq, ilike, and } from "drizzle-orm";
import { templates as templateData } from "@/lib/data/templates";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const style = searchParams.get("style");
    const search = searchParams.get("search");
    const country = searchParams.get("country");
    const premium = searchParams.get("premium");

    let conditions = [];
    if (category) conditions.push(eq(templates.category, category));
    if (style) conditions.push(eq(templates.style, style));
    if (country) conditions.push(eq(templates.country, country));
    if (search) conditions.push(ilike(templates.name, `%${search}%`));
    if (premium) conditions.push(eq(templates.isPremium, premium === "true"));

    let result;
    if (conditions.length > 0) {
      result = await db
        .select()
        .from(templates)
        .where(and(...conditions))
        .orderBy(templates.createdAt);
    } else {
      result = await db.select().from(templates).orderBy(templates.createdAt);
    }

    // If no templates in DB, return static data
    if (result.length === 0) {
      return NextResponse.json({
        success: true,
        templates: templateData,
        source: "static",
      });
    }

    return NextResponse.json({
      success: true,
      templates: result,
      source: "database",
    });
  } catch (error) {
    console.error("Error fetching templates:", error);
    // Fall back to static data
    return NextResponse.json({
      success: true,
      templates: templateData,
      source: "static",
    });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, category, style, previewImage, config, isPremium, country } = body;

    if (!name || !category || !style) {
      return NextResponse.json(
        { error: "Name, category, and style are required" },
        { status: 400 }
      );
    }

    const result = await db
      .insert(templates)
      .values({
        name,
        category,
        style,
        previewImage,
        config,
        isPremium: isPremium || false,
        country,
      })
      .returning();

    return NextResponse.json({ success: true, template: result[0] });
  } catch (error) {
    console.error("Error creating template:", error);
    return NextResponse.json(
      { error: "Failed to create template" },
      { status: 500 }
    );
  }
}
