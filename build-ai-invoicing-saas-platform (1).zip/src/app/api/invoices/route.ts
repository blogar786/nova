import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { invoices, invoiceItems, businesses, customers } from "@/db/schema";
import { eq, desc, and, ilike, gte, lte } from "drizzle-orm";
import { generateInvoiceNumber } from "@/lib/utils";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId") || "demo_user";
    const status = searchParams.get("status");
    const search = searchParams.get("search");
    const dateFrom = searchParams.get("dateFrom");
    const dateTo = searchParams.get("dateTo");

    let query = db
      .select()
      .from(invoices)
      .where(eq(invoices.userId, userId))
      .orderBy(desc(invoices.createdAt));

    const conditions = [eq(invoices.userId, userId)];
    if (status) conditions.push(eq(invoices.status, status));
    if (search) conditions.push(ilike(invoices.invoiceNumber, `%${search}%`));
    if (dateFrom) conditions.push(gte(invoices.createdAt, new Date(dateFrom)));
    if (dateTo) conditions.push(lte(invoices.createdAt, new Date(dateTo)));

    const result = await db
      .select()
      .from(invoices)
      .where(and(...conditions))
      .orderBy(desc(invoices.createdAt));

    return NextResponse.json({ success: true, invoices: result });
  } catch (error) {
    console.error("Error fetching invoices:", error);
    return NextResponse.json(
      { error: "Failed to fetch invoices" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId = "demo_user",
      businessId,
      customerId,
      invoiceNumber = generateInvoiceNumber(),
      status = "draft",
      currency = "USD",
      issueDate,
      dueDate,
      subtotal = "0",
      taxAmount = "0",
      discountAmount = "0",
      shippingAmount = "0",
      totalAmount = "0",
      taxType = "VAT",
      taxRate = "0",
      paymentTerms = "NET_30",
      paymentMethod,
      paymentLink,
      notes,
      terms,
      fieldConfig,
      template = "modern",
      aiGenerated = false,
      aiPrompt,
      items = [],
    } = body;

    const result = await db
      .insert(invoices)
      .values({
        userId,
        businessId,
        customerId,
        invoiceNumber,
        status,
        currency,
        issueDate: issueDate ? new Date(issueDate) : new Date(),
        dueDate: dueDate ? new Date(dueDate) : undefined,
        subtotal,
        taxAmount,
        discountAmount,
        shippingAmount,
        totalAmount,
        taxType,
        taxRate,
        paymentTerms,
        paymentMethod,
        paymentLink,
        notes,
        terms,
        fieldConfig,
        template,
        aiGenerated,
        aiPrompt,
      })
      .returning();

    // Insert invoice items
    if (items.length > 0) {
      await db.insert(invoiceItems).values(
        items.map((item: any) => ({
          invoiceId: result[0].id,
          description: item.description,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          taxRate: item.taxRate,
          taxAmount: item.taxAmount,
          discount: item.discount,
          total: item.total,
        }))
      );
    }

    return NextResponse.json({ success: true, invoice: result[0] });
  } catch (error) {
    console.error("Error creating invoice:", error);
    return NextResponse.json(
      { error: "Failed to create invoice" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json(
        { error: "Invoice ID is required" },
        { status: 400 }
      );
    }

    const result = await db
      .update(invoices)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(invoices.id, id))
      .returning();

    return NextResponse.json({ success: true, invoice: result[0] });
  } catch (error) {
    console.error("Error updating invoice:", error);
    return NextResponse.json(
      { error: "Failed to update invoice" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { error: "Invoice ID is required" },
        { status: 400 }
      );
    }

    await db.delete(invoices).where(eq(invoices.id, id));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting invoice:", error);
    return NextResponse.json(
      { error: "Failed to delete invoice" },
      { status: 500 }
    );
  }
}
