import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { invoices, invoiceItems } from "@/db/schema";
import { eq, gte, lte, sql } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId") || "demo_user";
    const period = searchParams.get("period") || "12m";

    // Mock analytics data for demo
    const mockAnalytics = {
      monthlyIncome: [
        { month: "Jan", amount: 3200 },
        { month: "Feb", amount: 4100 },
        { month: "Mar", amount: 3800 },
        { month: "Apr", amount: 5200 },
        { month: "May", amount: 4600 },
        { month: "Jun", amount: 5800 },
        { month: "Jul", amount: 6200 },
        { month: "Aug", amount: 5400 },
        { month: "Sep", amount: 6800 },
        { month: "Oct", amount: 7200 },
        { month: "Nov", amount: 6400 },
        { month: "Dec", amount: 8200 },
      ],
      taxSummary: [
        { type: "VAT (20%)", amount: 8420.5 },
        { type: "GST (10%)", amount: 1200.0 },
        { type: "Sales Tax (7.5%)", amount: 980.5 },
        { type: "Withholding Tax (15%)", amount: 450.0 },
      ],
      outstandingBalance: 18750.0,
      customerActivity: [
        { name: "TechCorp Solutions", count: 12 },
        { name: "Ahmed Trading Dubai", count: 8 },
        { name: "Sarah Johnson", count: 5 },
        { name: "Digital Agency Pro", count: 4 },
        { name: "Global Imports Ltd", count: 3 },
      ],
      revenuePrediction: [
        { month: "Jan", amount: 3400 },
        { month: "Feb", amount: 4300 },
        { month: "Mar", amount: 4800 },
        { month: "Apr", amount: 5200 },
        { month: "May", amount: 5600 },
        { month: "Jun", amount: 6100 },
      ],
      latePaymentPrediction: 12,
      totalInvoices: 155,
      totalRevenue: 65400.5,
      paidInvoices: 127,
      pendingInvoices: 23,
      overdueInvoices: 5,
      draftInvoices: 8,
    };

    return NextResponse.json({
      success: true,
      analytics: mockAnalytics,
    });
  } catch (error) {
    console.error("Error fetching analytics:", error);
    return NextResponse.json(
      { error: "Failed to fetch analytics" },
      { status: 500 }
    );
  }
}
