import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { HeroSection } from "@/components/home/hero-section";
import { FeaturesSection } from "@/components/home/features-section";
import { TemplatesShowcase } from "@/components/home/templates-showcase";
import { HowItWorksSection } from "@/components/home/how-it-works";
import { AIShowcaseSection } from "@/components/home/ai-showcase";
import { PricingSection } from "@/components/home/pricing-section";
import { CTASection } from "@/components/home/cta-section";

export default function HomePage() {
  return (
    <>
      <Header />
      <main>
        <HeroSection />
        <FeaturesSection />
        <TemplatesShowcase />
        <HowItWorksSection />
        <AIShowcaseSection />
        <PricingSection />
        <CTASection />
      </main>
      <Footer />
    </>
  );
}
