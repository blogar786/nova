import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AuthProvider } from "@/components/auth/auth-context";
import { ThemeProvider } from "@/components/ui/theme-provider";

export const metadata: Metadata = {
  title: "InvoiceNova — AI Invoice Generator for Every Business Worldwide",
  description: "Create beautiful invoices in seconds with AI. Every country. Every currency. Every tax system. Every invoice template.",
  keywords: "invoice, AI invoice generator, invoicing, billing, accounting, templates, VAT, GST, sales tax",
  authors: [{ name: "InvoiceNova" }],
  openGraph: {
    title: "InvoiceNova — AI Invoice Generator for Every Business Worldwide",
    description: "Create beautiful invoices in seconds with AI. Every country. Every currency. Every tax system. Every invoice template.",
    url: "https://invoicenova.com",
    siteName: "InvoiceNova",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="bg-background text-foreground antialiased overflow-x-hidden">
        <ThemeProvider>
          <AuthProvider>
            {children}
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
