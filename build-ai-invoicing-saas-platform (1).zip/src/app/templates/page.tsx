"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { templates, templateCategories } from "@/lib/data/templates";
import { Search, Filter, Star, Sparkles, Grid, List } from "lucide-react";
import Link from "next/link";

export default function TemplatesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const filteredTemplates = templates.filter((template) => {
    const matchesSearch =
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (template.country || "").toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <>
      <Header />
      <main className="min-h-screen bg-slate-50/30 dark:bg-slate-900/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12"
          >
            <h1 className="text-4xl font-bold tracking-tight text-slate-900 dark:text-slate-100 mb-4">
              Invoice Template Library
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-300 max-w-3xl">
              The world's largest collection of professional invoice templates across 40+ industries
              and every country. Find the perfect template for your business.
            </p>
          </motion.div>

          {/* Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="mb-8 flex flex-col sm:flex-row gap-4 items-center justify-between"
          >
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
              <Input
                placeholder="Search templates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12"
              />
            </div>
            <div className="flex items-center gap-4">
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={selectedCategory === "All" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory("All")}
                >
                  All
                </Button>
                {templateCategories.slice(0, 8).map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Button>
                ))}
              </div>
              <div className="flex items-center gap-1 border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-1">
                <Button
                  variant={viewMode === "grid" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Results count */}
          <div className="mb-6 flex items-center justify-between">
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Showing {filteredTemplates.length} of {templates.length} templates
            </p>
            <Badge variant="outline">
              {filteredTemplates.filter((t) => t.isPremium).length} Premium
            </Badge>
          </div>

          {/* Templates Grid */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className={
              viewMode === "grid"
                ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
                : "space-y-4"
            }
          >
            {filteredTemplates.map((template, index) => (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.03 }}
              >
                {viewMode === "grid" ? (
                  <Card className="group h-full border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30 hover:shadow-2xl transition-all duration-300 overflow-hidden">
                    <div className="relative aspect-[3/2] overflow-hidden bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800">
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <div className="mb-2 text-4xl font-bold text-slate-400 dark:text-slate-500">
                          {template.previewImage?.split("-")[0]?.charAt(0).toUpperCase() || "T"}
                        </div>
                        <div className="text-xs text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                          {template.category} Template
                        </div>
                        <div className="mt-2 text-xs text-slate-400 dark:text-slate-500">
                          {template.style} • {template.country || "Global"}
                        </div>
                      </div>
                      {template.isPremium && (
                        <div className="absolute top-3 right-3">
                          <Badge variant="premium" className="text-xs">
                            <Star className="h-3 w-3 mr-1" />
                            Premium
                          </Badge>
                        </div>
                      )}
                      <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-black/50 to-transparent flex items-end">
                        <span className="text-xs text-white px-3 pb-2 font-medium">
                          {template.name}
                        </span>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-1">
                        {template.name}
                      </h3>
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-xs">
                          {template.category}
                        </Badge>
                        {template.country && (
                          <Badge variant="outline" className="text-xs">
                            {template.country}
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                    <div className="px-4 pb-4">
                      <Link href="/generator">
                        <Button variant="gradient" size="sm" className="w-full group">
                          <Sparkles className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform" />
                          Use This Template
                        </Button>
                      </Link>
                    </div>
                  </Card>
                ) : (
                  <Card className="group border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30 hover:shadow-xl transition-all duration-300">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <div className="flex h-16 w-24 flex-shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800">
                          <span className="text-3xl font-bold text-slate-400 dark:text-slate-500">
                            {template.previewImage?.split("-")[0]?.charAt(0).toUpperCase() || "T"}
                          </span>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-slate-900 dark:text-slate-100">
                              {template.name}
                            </h3>
                            {template.isPremium && (
                              <Badge variant="premium" className="text-xs">
                                <Star className="h-3 w-3" />
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              {template.category}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {template.style}
                            </Badge>
                            {template.country && (
                              <Badge variant="outline" className="text-xs">
                                {template.country}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <Link href="/generator">
                          <Button variant="gradient" size="sm" className="group">
                            <Sparkles className="h-4 w-4 mr-2" />
                            Use
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </motion.div>
            ))}
          </motion.div>

          {filteredTemplates.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <Search className="mx-auto h-12 w-12 text-slate-300 dark:text-slate-600 mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
                No templates found
              </h3>
              <p className="text-slate-500 dark:text-slate-400">
                Try adjusting your search or filter criteria.
              </p>
            </motion.div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
