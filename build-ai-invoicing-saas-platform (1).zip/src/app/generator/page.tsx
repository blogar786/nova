"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { AIPromptInput } from "@/components/generator/ai-prompt-input";
import { FieldToggles } from "@/components/generator/field-toggles";
import { InvoicePreview } from "@/components/generator/invoice-preview";
import { AIErrorDetection } from "@/components/generator/ai-error-detection";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Plus, Trash2, Save, Send, Download, FileText, Bot, CheckCircle,
  Building, User, Calendar, Globe, Percent, CreditCard,
  FileCheck, Sparkles, Loader2, Eye, Settings
} from "lucide-react";
import { generateInvoiceNumber, calculateInvoiceTotals } from "@/lib/utils";
import { fieldToggles } from "@/lib/data/field-toggles";
import { countries } from "@/lib/data/countries";
import { AIError, InvoiceItem } from "@/lib/types";

interface BusinessInfo {
  name: string;
  email: string;
  phone: string;
  address: string;
  website: string;
  taxNumber: string;
  vatNumber: string;
  gstNumber: string;
  logo: string;
}

interface CustomerInfo {
  name: string;
  email: string;
  phone: string;
  address: string;
  billingAddress: string;
  shippingAddress: string;
  taxNumber: string;
  vatNumber: string;
}

interface InvoiceInfo {
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  purchaseOrderNumber: string;
  referenceNumber: string;
  currency: string;
  paymentTerms: string;
  paymentMethod: string;
  notes: string;
  terms: string;
  country: string;
  taxType: string;
  taxRate: number;
  discountAmount: number;
  shippingAmount: number;
  extraCharges: number;
  insurance: number;
  lateFee: number;
}

export default function GeneratorPage() {
  // State
  const [business, setBusiness] = useState<BusinessInfo>({
    name: "InvoiceNova Inc.",
    email: "hello@invoicenova.com",
    phone: "+1 (555) 123-4567",
    address: "123 Innovation Drive, San Francisco, CA 94105, USA",
    website: "www.invoicenova.com",
    taxNumber: "TX-123456789",
    vatNumber: "VAT-987654321",
    gstNumber: "GST-456789123",
    logo: "",
  });

  const [customer, setCustomer] = useState<CustomerInfo>({
    name: "",
    email: "",
    phone: "",
    address: "",
    billingAddress: "",
    shippingAddress: "",
    taxNumber: "",
    vatNumber: "",
  });

  const [items, setItems] = useState<InvoiceItem[]>([
    { description: "", quantity: 1, unitPrice: 0, taxRate: 0, taxAmount: 0, discount: 0, total: 0 },
  ]);

  const [invoiceInfo, setInvoiceInfo] = useState<InvoiceInfo>({
    invoiceNumber: generateInvoiceNumber(),
    issueDate: new Date().toISOString().split("T")[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    purchaseOrderNumber: "",
    referenceNumber: "",
    currency: "USD",
    paymentTerms: "NET_30",
    paymentMethod: "stripe",
    notes: "Thank you for your business!",
    terms: "Payment is due within 30 days. Late payments may incur additional fees.",
    country: "US",
    taxType: "Sales Tax",
    taxRate: 7.5,
    discountAmount: 0,
    shippingAmount: 0,
    extraCharges: 0,
    insurance: 0,
    lateFee: 0,
  });

  // Initialize field config
  const initialFieldConfig = fieldToggles.reduce((acc, field) => {
    acc[field.key] = field.defaultOn;
    return acc;
  }, {} as Record<string, boolean>);

  const [fieldConfig, setFieldConfig] = useState<Record<string, boolean>>(initialFieldConfig);
  const [errors, setErrors] = useState<AIError[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [activeTab, setActiveTab] = useState("form");

  // Calculate totals
  const totals = calculateInvoiceTotals(
    items.map((item) => ({ total: item.total })),
    invoiceInfo.taxRate,
    invoiceInfo.discountAmount,
    invoiceInfo.shippingAmount
  );

  // Update item total when quantity or unit price changes
  const updateItem = (index: number, field: keyof InvoiceItem, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };

    // Recalculate item total
    const item = newItems[index];
    const subtotal = (item.quantity || 0) * (item.unitPrice || 0);
    const itemDiscount = item.discount || 0;
    const itemTaxAmount = (subtotal - itemDiscount) * ((item.taxRate || 0) / 100);
    item.total = subtotal - itemDiscount + itemTaxAmount;
    item.taxAmount = itemTaxAmount;

    setItems(newItems);
  };

  const addItem = () => {
    setItems([
      ...items,
      { description: "", quantity: 1, unitPrice: 0, taxRate: invoiceInfo.taxRate, taxAmount: 0, discount: 0, total: 0 },
    ]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  // AI Generation
  const handleAIGenerate = async (prompt: string) => {
    setIsGenerating(true);
    try {
      const response = await fetch("/api/ai/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, business, customer, items, invoiceInfo }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.business) setBusiness({ ...business, ...data.business });
        if (data.customer) setCustomer({ ...customer, ...data.customer });
        if (data.items) setItems(data.items);
        if (data.invoiceInfo) setInvoiceInfo({ ...invoiceInfo, ...data.invoiceInfo });
      }
    } catch (error) {
      console.error("AI generation failed:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  // AI Error Detection
  const runErrorDetection = async () => {
    setIsChecking(true);
    try {
      const response = await fetch("/api/ai/detect-errors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ business, customer, items, invoiceInfo, fieldConfig }),
      });

      if (response.ok) {
        const data = await response.json();
        setErrors(data.errors || []);
      }
    } catch (error) {
      console.error("Error detection failed:", error);
    } finally {
      setIsChecking(false);
    }
  };

  // Auto-run error detection on changes
  useEffect(() => {
    const timer = setTimeout(() => {
      runErrorDetection();
    }, 1000);
    return () => clearTimeout(timer);
  }, [items, invoiceInfo, customer, business]);

  const handleExport = (format: string) => {
    console.log(`Exporting as ${format}...`);
  };

  const handleFixError = (error: AIError) => {
    console.log("Fixing error:", error);
  };

  const handleCountryChange = (countryCode: string) => {
    const country = countries.find((c) => c.code === countryCode);
    if (country) {
      setInvoiceInfo({
        ...invoiceInfo,
        country: countryCode,
        currency: country.currency,
        taxType: country.taxType,
        taxRate: country.taxRate,
      });
    }
  };

  return (
    <>
      <Header />
      <main className="min-h-screen bg-slate-50/30 dark:bg-slate-900/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Page Header */}
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">
                AI Invoice Generator
              </h1>
              <p className="text-slate-600 dark:text-slate-400">
                Create professional invoices with AI assistance and smart field controls
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" onClick={() => setActiveTab("preview")}>
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </Button>
              <Button variant="gradient" size="sm" onClick={() => handleExport("pdf")}>
                <Download className="h-4 w-4 mr-2" />
                Export PDF
              </Button>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-slate-100/50 dark:bg-slate-800/50 p-1 rounded-xl">
              <TabsTrigger value="form" className="data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800">
                <Bot className="h-4 w-4 mr-2" />
                AI Generator
              </TabsTrigger>
              <TabsTrigger value="toggles" className="data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800">
                <Settings className="h-4 w-4 mr-2" />
                Field Toggles
              </TabsTrigger>
              <TabsTrigger value="errors" className="data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800">
                <FileCheck className="h-4 w-4 mr-2" />
                AI Error Detection
                {errors.length > 0 && (
                  <Badge variant="destructive" className="ml-2 h-5 w-5 rounded-full p-0 text-xs">
                    {errors.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="preview" className="data-[state=active]:bg-white dark:data-[state=active]:bg-slate-800">
                <FileText className="h-4 w-4 mr-2" />
                Invoice Preview
              </TabsTrigger>
            </TabsList>

            {/* AI Generator Tab */}
            <TabsContent value="form" className="space-y-6">
              <AIPromptInput onGenerate={handleAIGenerate} isLoading={isGenerating} />

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Business Info */}
                <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <Building className="h-5 w-5 text-primary-600 dark:text-primary-400" />
                      Business Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Input
                      label="Business Name"
                      value={business.name}
                      onChange={(e) => setBusiness({ ...business, name: e.target.value })}
                      placeholder="Your company name"
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        label="Email"
                        type="email"
                        value={business.email}
                        onChange={(e) => setBusiness({ ...business, email: e.target.value })}
                        placeholder="hello@company.com"
                      />
                      <Input
                        label="Phone"
                        value={business.phone}
                        onChange={(e) => setBusiness({ ...business, phone: e.target.value })}
                        placeholder="+1 (555) 123-4567"
                      />
                    </div>
                    <Input
                      label="Address"
                      value={business.address}
                      onChange={(e) => setBusiness({ ...business, address: e.target.value })}
                      placeholder="123 Business St, City, State, ZIP"
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        label="Website"
                        value={business.website}
                        onChange={(e) => setBusiness({ ...business, website: e.target.value })}
                        placeholder="www.company.com"
                      />
                      <Input
                        label="Tax Number"
                        value={business.taxNumber}
                        onChange={(e) => setBusiness({ ...business, taxNumber: e.target.value })}
                        placeholder="TX-123456789"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        label="VAT Number"
                        value={business.vatNumber}
                        onChange={(e) => setBusiness({ ...business, vatNumber: e.target.value })}
                        placeholder="VAT-987654321"
                      />
                      <Input
                        label="GST Number"
                        value={business.gstNumber}
                        onChange={(e) => setBusiness({ ...business, gstNumber: e.target.value })}
                        placeholder="GST-456789123"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Customer Info */}
                <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <User className="h-5 w-5 text-primary-600 dark:text-primary-400" />
                      Customer Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Input
                      label="Customer Name"
                      value={customer.name}
                      onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                      placeholder="John Doe"
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        label="Email"
                        type="email"
                        value={customer.email}
                        onChange={(e) => setCustomer({ ...customer, email: e.target.value })}
                        placeholder="john@customer.com"
                      />
                      <Input
                        label="Phone"
                        value={customer.phone}
                        onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                        placeholder="+1 (555) 987-6543"
                      />
                    </div>
                    <Input
                      label="Address"
                      value={customer.address}
                      onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
                      placeholder="123 Customer St, City, State, ZIP"
                    />
                    <Input
                      label="Billing Address"
                      value={customer.billingAddress}
                      onChange={(e) => setCustomer({ ...customer, billingAddress: e.target.value })}
                      placeholder="Same as address"
                    />
                    <Input
                      label="Shipping Address"
                      value={customer.shippingAddress}
                      onChange={(e) => setCustomer({ ...customer, shippingAddress: e.target.value })}
                      placeholder="Same as address"
                    />
                  </CardContent>
                </Card>
              </div>

              {/* Invoice Items */}
              <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <FileText className="h-5 w-5 text-primary-600 dark:text-primary-400" />
                      Invoice Items
                    </CardTitle>
                    <Button variant="outline" size="sm" onClick={addItem}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Item
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-slate-200 dark:border-slate-700">
                          <th className="text-left py-3 font-semibold text-slate-900 dark:text-slate-100">Description</th>
                          <th className="text-right py-3 font-semibold text-slate-900 dark:text-slate-100 w-20">Qty</th>
                          <th className="text-right py-3 font-semibold text-slate-900 dark:text-slate-100 w-32">Unit Price</th>
                          <th className="text-right py-3 font-semibold text-slate-900 dark:text-slate-100 w-20">Tax %</th>
                          <th className="text-right py-3 font-semibold text-slate-900 dark:text-slate-100 w-32">Total</th>
                          <th className="w-10"></th>
                        </tr>
                      </thead>
                      <tbody>
                        {items.map((item, index) => (
                          <tr key={index} className="border-b border-slate-200/50 dark:border-slate-700/50">
                            <td className="py-3">
                              <Input
                                value={item.description}
                                onChange={(e) => updateItem(index, "description", e.target.value)}
                                placeholder="Product or service description"
                                className="border-0 shadow-none focus:ring-0 bg-transparent"
                              />
                            </td>
                            <td className="py-3">
                              <Input
                                type="number"
                                value={item.quantity}
                                onChange={(e) => updateItem(index, "quantity", parseFloat(e.target.value) || 0)}
                                className="border-0 shadow-none focus:ring-0 bg-transparent text-right"
                              />
                            </td>
                            <td className="py-3">
                              <Input
                                type="number"
                                value={item.unitPrice}
                                onChange={(e) => updateItem(index, "unitPrice", parseFloat(e.target.value) || 0)}
                                className="border-0 shadow-none focus:ring-0 bg-transparent text-right"
                              />
                            </td>
                            <td className="py-3">
                              <Input
                                type="number"
                                value={item.taxRate}
                                onChange={(e) => updateItem(index, "taxRate", parseFloat(e.target.value) || 0)}
                                className="border-0 shadow-none focus:ring-0 bg-transparent text-right"
                              />
                            </td>
                            <td className="py-3 text-right font-medium">
                              {item.total.toFixed(2)}
                            </td>
                            <td className="py-3">
                              {items.length > 1 && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeItem(index)}
                                  className="text-red-500 hover:text-red-600"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Invoice Details */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-primary-600 dark:text-primary-400" />
                      Invoice Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Input
                      label="Invoice Number"
                      value={invoiceInfo.invoiceNumber}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, invoiceNumber: e.target.value })}
                    />
                    <Input
                      label="Issue Date"
                      type="date"
                      value={invoiceInfo.issueDate}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, issueDate: e.target.value })}
                    />
                    <Input
                      label="Due Date"
                      type="date"
                      value={invoiceInfo.dueDate}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, dueDate: e.target.value })}
                    />
                    <Input
                      label="Purchase Order Number"
                      value={invoiceInfo.purchaseOrderNumber}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, purchaseOrderNumber: e.target.value })}
                      placeholder="PO-12345"
                    />
                    <Input
                      label="Reference Number"
                      value={invoiceInfo.referenceNumber}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, referenceNumber: e.target.value })}
                      placeholder="REF-67890"
                    />
                  </CardContent>
                </Card>

                <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <Globe className="h-5 w-5 text-primary-600 dark:text-primary-400" />
                      Country & Currency
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        Country
                      </label>
                      <select
                        value={invoiceInfo.country}
                        onChange={(e) => handleCountryChange(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white/50 dark:bg-slate-800/50 px-4 py-3 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                      >
                        {countries.map((country) => (
                          <option key={country.code} value={country.code}>
                            {country.flag} {country.name} ({country.currency})
                          </option>
                        ))}
                      </select>
                    </div>
                    <Input
                      label="Currency"
                      value={invoiceInfo.currency}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, currency: e.target.value })}
                    />
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        Tax Type
                      </label>
                      <select
                        value={invoiceInfo.taxType}
                        onChange={(e) => setInvoiceInfo({ ...invoiceInfo, taxType: e.target.value })}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white/50 dark:bg-slate-800/50 px-4 py-3 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                      >
                        <option value="VAT">VAT</option>
                        <option value="GST">GST</option>
                        <option value="Sales Tax">Sales Tax</option>
                        <option value="Withholding Tax">Withholding Tax</option>
                        <option value="Reverse Charge">Reverse Charge</option>
                        <option value="QST">QST (Quebec)</option>
                        <option value="HST">HST (Canada)</option>
                        <option value="No Tax">No Tax</option>
                      </select>
                    </div>
                    <Input
                      label="Tax Rate (%)"
                      type="number"
                      value={invoiceInfo.taxRate}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, taxRate: parseFloat(e.target.value) || 0 })}
                      icon={<Percent className="h-4 w-4" />}
                    />
                  </CardContent>
                </Card>

                <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <CreditCard className="h-5 w-5 text-primary-600 dark:text-primary-400" />
                      Payment & Totals
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Input
                      label="Payment Terms"
                      value={invoiceInfo.paymentTerms}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, paymentTerms: e.target.value })}
                      placeholder="NET_30"
                    />
                    <Input
                      label="Discount Amount"
                      type="number"
                      value={invoiceInfo.discountAmount}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, discountAmount: parseFloat(e.target.value) || 0 })}
                    />
                    <Input
                      label="Shipping Charges"
                      type="number"
                      value={invoiceInfo.shippingAmount}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, shippingAmount: parseFloat(e.target.value) || 0 })}
                    />
                    <Input
                      label="Extra Charges"
                      type="number"
                      value={invoiceInfo.extraCharges}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, extraCharges: parseFloat(e.target.value) || 0 })}
                    />
                    <div className="pt-4 border-t border-slate-200 dark:border-slate-700">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-300">Subtotal:</span>
                          <span className="font-medium">{totals.subtotal} {invoiceInfo.currency}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600 dark:text-slate-300">Tax:</span>
                          <span className="font-medium">{totals.taxAmount} {invoiceInfo.currency}</span>
                        </div>
                        <div className="flex justify-between text-lg font-bold">
                          <span className="text-slate-900 dark:text-slate-100">Total:</span>
                          <span className="bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
                            {totals.total} {invoiceInfo.currency}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Notes & Terms */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                      Notes
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      value={invoiceInfo.notes}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, notes: e.target.value })}
                      placeholder="Additional notes for the customer..."
                      className="min-h-[120px]"
                    />
                  </CardContent>
                </Card>
                <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                      Terms & Conditions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      value={invoiceInfo.terms}
                      onChange={(e) => setInvoiceInfo({ ...invoiceInfo, terms: e.target.value })}
                      placeholder="Payment terms and conditions..."
                      className="min-h-[120px]"
                    />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Field Toggles Tab */}
            <TabsContent value="toggles">
              <FieldToggles fieldConfig={fieldConfig} onChange={setFieldConfig} />
            </TabsContent>

            {/* Error Detection Tab */}
            <TabsContent value="errors">
              <AIErrorDetection
                errors={errors}
                onFix={handleFixError}
                onRecheck={runErrorDetection}
                isChecking={isChecking}
              />
            </TabsContent>

            {/* Preview Tab */}
            <TabsContent value="preview">
              <InvoicePreview
                invoice={invoiceInfo}
                business={business}
                customer={customer}
                items={items}
                fieldConfig={fieldConfig}
                onExport={handleExport}
              />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </>
  );
}
