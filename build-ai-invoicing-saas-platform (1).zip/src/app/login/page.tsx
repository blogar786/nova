"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useAuth } from "@/components/auth/auth-context";
import { Sparkles, Mail, Lock, User, Globe, ArrowRight } from "lucide-react";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const { signIn, signUp, isLoading } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    firstName: "",
    lastName: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isLogin) {
        await signIn(formData.email, formData.password);
      } else {
        await signUp(formData.email, formData.password, formData.firstName, formData.lastName);
      }
      router.push("/dashboard");
    } catch (error) {
      console.error("Auth error:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50 dark:from-slate-900 dark:via-slate-950 dark:to-slate-900 flex items-center justify-center p-4">
      {/* Background elements */}
      <div className="absolute top-0 -left-24 h-96 w-96 rounded-full bg-gradient-to-br from-primary-300/20 to-secondary-300/20 blur-3xl" />
      <div className="absolute bottom-0 -right-24 h-96 w-96 rounded-full bg-gradient-to-tr from-secondary-300/20 to-primary-300/20 blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="w-full max-w-md"
      >
        <div className="mb-8 text-center">
          <Link href="/" className="inline-flex items-center space-x-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary-600 to-secondary-600">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
              InvoiceNova
            </span>
          </Link>
        </div>

        <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30 shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center text-slate-900 dark:text-slate-100">
              {isLogin ? "Welcome Back" : "Create Your Account"}
            </CardTitle>
            <CardDescription className="text-center text-slate-500 dark:text-slate-400">
              {isLogin
                ? "Sign in to access your dashboard"
                : "Start your 14-day free trial today"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="grid grid-cols-2 gap-4"
                >
                  <Input
                    label="First Name"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    placeholder="Alex"
                    icon={<User className="h-4 w-4" />}
                  />
                  <Input
                    label="Last Name"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    placeholder="Chen"
                    icon={<User className="h-4 w-4" />}
                  />
                </motion.div>
              )}
              <Input
                label="Email Address"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="hello@invoicenova.com"
                icon={<Mail className="h-4 w-4" />}
              />
              <Input
                label="Password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="••••••••"
                icon={<Lock className="h-4 w-4" />}
              />
              <Button type="submit" variant="gradient" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  "Please wait..."
                ) : isLogin ? (
                  "Sign In"
                ) : (
                  "Create Account"
                )}
              </Button>
            </form>

            <div className="my-6 flex items-center">
              <div className="flex-1 border-t border-slate-200 dark:border-slate-700" />
              <span className="px-3 text-xs text-slate-500 dark:text-slate-400">OR</span>
              <div className="flex-1 border-t border-slate-200 dark:border-slate-700" />
            </div>

              <Button variant="outline" className="w-full" type="button">
              <Globe className="h-4 w-4 mr-2" />
              Continue with Google
            </Button>

            <div className="mt-6 text-center text-sm">
              <span className="text-slate-500 dark:text-slate-400">
                {isLogin ? "Don't have an account?" : "Already have an account?"}
              </span>{" "}
              <button
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="font-medium text-primary-600 dark:text-primary-400 hover:underline"
              >
                {isLogin ? "Sign up" : "Sign in"}
              </button>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 text-center">
          <Link
            href="/"
            className="text-sm text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 transition-colors"
          >
            ← Back to Homepage
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
