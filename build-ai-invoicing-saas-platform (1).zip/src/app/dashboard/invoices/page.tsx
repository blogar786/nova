"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Search, Filter, Download, Send, MoreHorizontal, FileText,
  CheckCircle, Clock, AlertCircle, Edit, Copy, Trash2, Plus,
  ChevronLeft, ChevronRight, ArrowUpDown
} from "lucide-react";
import { formatCurrency, formatDate, getStatusColor, getStatusLabel } from "@/lib/utils";
import Link from "next/link";

const allInvoices = [
  { id: "inv_001", invoiceNumber: "INV-2024-0012", customer: "TechCorp Solutions", email: "contact@techcorp.com", date: "2024-12-15", dueDate: "2025-01-15", amount: 4500.0, status: "paid", items: 3, currency: "USD" },
  { id: "inv_002", invoiceNumber: "INV-2024-0013", customer: "Ahmed Trading Dubai", email: "ahmed@tradingdubai.com", date: "2024-12-20", dueDate: "2025-01-20", amount: 12500.0, status: "pending", items: 10, currency: "USD" },
  { id: "inv_003", invoiceNumber: "INV-2024-0014", customer: "Sarah Johnson", email: "sarah@consulting.com", date: "2024-12-18", dueDate: "2025-01-18", amount: 3200.0, status: "overdue", items: 2, currency: "USD" },
  { id: "inv_004", invoiceNumber: "INV-2024-0015", customer: "Digital Agency Pro", email: "hello@digitalpro.com", date: "2024-12-22", dueDate: "2025-01-22", amount: 8750.0, status: "sent", items: 5, currency: "USD" },
  { id: "inv_005", invoiceNumber: "INV-2024-0016", customer: "Global Imports Ltd", email: "info@globalimports.com", date: "2024-12-25", dueDate: "2025-01-25", amount: 15600.0, status: "draft", items: 8, currency: "USD" },
  { id: "inv_006", invoiceNumber: "INV-2024-0017", customer: "Creative Studio", email: "studio@creative.com", date: "2024-12-10", dueDate: "2025-01-10", amount: 5400.0, status: "paid", items: 4, currency: "EUR" },
  { id: "inv_007", invoiceNumber: "INV-2024-0018", customer: "Healthcare Plus", email: "admin@healthcareplus.com", date: "2024-12-05", dueDate: "2025-01-05", amount: 9200.0, status: "paid", items: 6, currency: "USD" },
  { id: "inv_008", invoiceNumber: "INV-2024-0019", customer: "Restaurant Group", email: "finance@restaurantgroup.com", date: "2024-12-01", dueDate: "2025-01-01", amount: 3800.0, status: "overdue", items: 3, currency: "USD" },
  { id: "inv_009", invoiceNumber: "INV-2024-0020", customer: "Construction Co", email: "billing@constructionco.com", date: "2024-11-28", dueDate: "2024-12-28", amount: 22500.0, status: "paid", items: 12, currency: "USD" },
  { id: "inv_010", invoiceNumber: "INV-2024-0021", customer: "Freelance Designer", email: "hello@freelance.com", date: "2024-11-25", dueDate: "2024-12-25", amount: 1800.0, status: "sent", items: 1, currency: "GBP" },
];

const statusFilters = ["All", "Draft", "Sent", "Pending", "Paid", "Overdue"];

export default function InvoicesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const filteredInvoices = allInvoices.filter((invoice) => {
    const matchesSearch =
      invoice.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.customer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "All" || invoice.status === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  const totalPages = Math.ceil(filteredInvoices.length / itemsPerPage);
  const paginatedInvoices = filteredInvoices.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "paid": return CheckCircle;
      case "pending": return Clock;
      case "overdue": return AlertCircle;
      default: return FileText;
    }
  };

  return (
    <>
      <Header />
      <main className="min-h-screen bg-slate-50/30 dark:bg-slate-900/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">
                All Invoices
              </h1>
              <p className="text-slate-600 dark:text-slate-400">
                Manage and track all your invoices in one place
              </p>
            </div>
            <Link href="/generator">
              <Button variant="gradient">
                <Plus className="h-4 w-4 mr-2" />
                New Invoice
              </Button>
            </Link>
          </div>

          {/* Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6 flex flex-col sm:flex-row gap-4 items-center justify-between"
          >
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
              <Input
                placeholder="Search invoices..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-slate-500 dark:text-slate-400" />
              {statusFilters.map((status) => (
                <Button
                  key={status}
                  variant={statusFilter === status ? "default" : "outline"}
                  size="sm"
                  onClick={() => setStatusFilter(status)}
                >
                  {status}
                </Button>
              ))}
            </div>
          </motion.div>

          {/* Results count */}
          <div className="mb-4 text-sm text-slate-600 dark:text-slate-400">
            Showing {filteredInvoices.length} of {allInvoices.length} invoices
          </div>

          {/* Invoices Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30 overflow-hidden">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                        <th className="text-left py-4 px-6 font-semibold text-slate-900 dark:text-slate-100">
                          <button className="flex items-center gap-1 hover:text-primary-600 dark:hover:text-primary-400">
                            Invoice <ArrowUpDown className="h-3 w-3" />
                          </button>
                        </th>
                        <th className="text-left py-4 px-6 font-semibold text-slate-900 dark:text-slate-100">Customer</th>
                        <th className="text-right py-4 px-6 font-semibold text-slate-900 dark:text-slate-100">Amount</th>
                        <th className="text-center py-4 px-6 font-semibold text-slate-900 dark:text-slate-100">Status</th>
                        <th className="text-right py-4 px-6 font-semibold text-slate-900 dark:text-slate-100">Date</th>
                        <th className="text-center py-4 px-6 font-semibold text-slate-900 dark:text-slate-100">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedInvoices.map((invoice, index) => {
                        const Icon = getStatusIcon(invoice.status);
                        return (
                          <motion.tr
                            key={invoice.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.3, delay: 0.05 * index }}
                            className="border-b border-slate-200/50 dark:border-slate-700/50 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                          >
                            <td className="py-4 px-6">
                              <div className="flex items-center gap-3">
                                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
                                  <FileText className="h-5 w-5 text-primary-600 dark:text-primary-400" />
                                </div>
                                <div>
                                  <p className="font-medium text-slate-900 dark:text-slate-100">
                                    {invoice.invoiceNumber}
                                  </p>
                                  <p className="text-xs text-slate-500 dark:text-slate-400">
                                    {invoice.items} items
                                  </p>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-6">
                              <p className="font-medium text-slate-900 dark:text-slate-100">{invoice.customer}</p>
                              <p className="text-sm text-slate-500 dark:text-slate-400">{invoice.email}</p>
                            </td>
                            <td className="py-4 px-6 text-right">
                              <p className="font-semibold text-slate-900 dark:text-slate-100">
                                {formatCurrency(invoice.amount, invoice.currency)}
                              </p>
                            </td>
                            <td className="py-4 px-6 text-center">
                              <Badge className={getStatusColor(invoice.status)}>
                                <Icon className="h-3 w-3 mr-1" />
                                {getStatusLabel(invoice.status)}
                              </Badge>
                            </td>
                            <td className="py-4 px-6 text-right text-slate-600 dark:text-slate-300">
                              {formatDate(invoice.date)}
                            </td>
                            <td className="py-4 px-6">
                              <div className="flex items-center justify-center gap-1">
                                <Button variant="ghost" size="sm">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Download className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Send className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </motion.tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Pagination */}
          {totalPages > 1 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mt-6 flex items-center justify-between"
            >
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Page {currentPage} of {totalPages}
              </p>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(page)}
                    className="w-10"
                  >
                    {page}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
