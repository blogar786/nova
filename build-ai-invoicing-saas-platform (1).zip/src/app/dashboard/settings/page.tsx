"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Settings, Save, Upload, Palette, Globe, Shield, Bell,
  Lock, User, Building, CreditCard, FileText, Mail,
  Smartphone, MapPin, Hash, Percent, Plus
} from "lucide-react";

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("business");
  const [settings, setSettings] = useState({
    businessName: "InvoiceNova Inc.",
    businessEmail: "hello@invoicenova.com",
    businessPhone: "+1 (555) 123-4567",
    businessAddress: "123 Innovation Drive, San Francisco, CA 94105, USA",
    businessWebsite: "www.invoicenova.com",
    taxNumber: "TX-123456789",
    vatNumber: "VAT-987654321",
    gstNumber: "GST-456789123",
    currency: "USD",
    country: "US",
    brandColor: "#3b82f6",
    brandFont: "Inter",
    watermark: false,
    twoFactorAuth: true,
    emailNotifications: true,
    smsNotifications: false,
    paymentReminders: true,
  });

  const tabs = [
    { id: "business", name: "Business Info", icon: Building },
    { id: "branding", name: "Branding", icon: Palette },
    { id: "payment", name: "Payment", icon: CreditCard },
    { id: "security", name: "Security", icon: Shield },
    { id: "notifications", name: "Notifications", icon: Bell },
  ];

  return (
    <>
      <Header />
      <main className="min-h-screen bg-slate-50/30 dark:bg-slate-900/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">
              Settings
            </h1>
            <p className="text-slate-600 dark:text-slate-400">
              Manage your business information, branding, and preferences
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                <CardContent className="p-2">
                  {tabs.map((tab) => {
                    const Icon = tab.icon;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-sm font-medium transition-all duration-200 ${
                          activeTab === tab.id
                            ? "bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400"
                            : "text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/50"
                        }`}
                      >
                        <Icon className="h-4 w-4" />
                        {tab.name}
                      </button>
                    );
                  })}
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                {activeTab === "business" && (
                  <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                    <CardHeader>
                      <CardTitle>Business Information</CardTitle>
                      <CardDescription>Update your company details</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Input
                          label="Business Name"
                          value={settings.businessName}
                          onChange={(e) => setSettings({ ...settings, businessName: e.target.value })}
                          icon={<Building className="h-4 w-4" />}
                        />
                        <Input
                          label="Business Email"
                          type="email"
                          value={settings.businessEmail}
                          onChange={(e) => setSettings({ ...settings, businessEmail: e.target.value })}
                          icon={<Mail className="h-4 w-4" />}
                        />
                        <Input
                          label="Phone"
                          value={settings.businessPhone}
                          onChange={(e) => setSettings({ ...settings, businessPhone: e.target.value })}
                          icon={<Smartphone className="h-4 w-4" />}
                        />
                        <Input
                          label="Website"
                          value={settings.businessWebsite}
                          onChange={(e) => setSettings({ ...settings, businessWebsite: e.target.value })}
                          icon={<Globe className="h-4 w-4" />}
                        />
                      </div>
                      <Input
                        label="Business Address"
                        value={settings.businessAddress}
                        onChange={(e) => setSettings({ ...settings, businessAddress: e.target.value })}
                        icon={<MapPin className="h-4 w-4" />}
                      />
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <Input
                          label="Tax Number"
                          value={settings.taxNumber}
                          onChange={(e) => setSettings({ ...settings, taxNumber: e.target.value })}
                          icon={<Hash className="h-4 w-4" />}
                        />
                        <Input
                          label="VAT Number"
                          value={settings.vatNumber}
                          onChange={(e) => setSettings({ ...settings, vatNumber: e.target.value })}
                          icon={<Hash className="h-4 w-4" />}
                        />
                        <Input
                          label="GST Number"
                          value={settings.gstNumber}
                          onChange={(e) => setSettings({ ...settings, gstNumber: e.target.value })}
                          icon={<Hash className="h-4 w-4" />}
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                            Country
                          </label>
                          <select
                            value={settings.country}
                            onChange={(e) => setSettings({ ...settings, country: e.target.value })}
                            className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white/50 dark:bg-slate-800/50 px-4 py-3 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                          >
                            <option value="US">United States</option>
                            <option value="GB">United Kingdom</option>
                            <option value="DE">Germany</option>
                            <option value="FR">France</option>
                            <option value="IN">India</option>
                            <option value="AE">UAE</option>
                          </select>
                        </div>
                        <Input
                          label="Default Currency"
                          value={settings.currency}
                          onChange={(e) => setSettings({ ...settings, currency: e.target.value.toUpperCase() })}
                        />
                      </div>
                    </CardContent>
                  </Card>
                )}

                {activeTab === "branding" && (
                  <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                    <CardHeader>
                      <CardTitle>Branding & Appearance</CardTitle>
                      <CardDescription>Customize your brand identity</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <Label className="mb-2">Company Logo</Label>
                        <div className="mt-2 flex items-center gap-4">
                          <div className="flex h-20 w-20 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
                            <Upload className="h-6 w-6 text-slate-400" />
                          </div>
                          <Button variant="outline" size="sm">
                            Upload Logo
                          </Button>
                        </div>
                      </div>

                      <div>
                        <Label className="mb-2">Brand Color</Label>
                        <div className="mt-2 flex items-center gap-4">
                          <input
                            type="color"
                            value={settings.brandColor}
                            onChange={(e) => setSettings({ ...settings, brandColor: e.target.value })}
                            className="h-10 w-20 rounded-xl cursor-pointer"
                          />
                          <Input
                            value={settings.brandColor}
                            onChange={(e) => setSettings({ ...settings, brandColor: e.target.value })}
                            className="max-w-32"
                          />
                        </div>
                      </div>

                      <div>
                        <Label className="mb-2">Brand Font</Label>
                        <select
                          value={settings.brandFont}
                          onChange={(e) => setSettings({ ...settings, brandFont: e.target.value })}
                          className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white/50 dark:bg-slate-800/50 px-4 py-3 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                        >
                          <option value="Inter">Inter (Modern)</option>
                          <option value="SF Pro Display">SF Pro Display (Apple)</option>
                          <option value="Fira Code">Fira Code (Monospace)</option>
                          <option value="Playfair Display">Playfair Display (Serif)</option>
                        </select>
                      </div>

                      <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-4">
                        <div>
                          <Label className="font-medium text-slate-900 dark:text-slate-100">
                            Watermark
                          </Label>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            Add a subtle watermark to your invoices
                          </p>
                        </div>
                        <Switch
                          checked={settings.watermark}
                          onCheckedChange={(checked) => setSettings({ ...settings, watermark: checked })}
                        />
                      </div>
                    </CardContent>
                  </Card>
                )}

                {activeTab === "payment" && (
                  <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                    <CardHeader>
                      <CardTitle>Payment Methods</CardTitle>
                      <CardDescription>Configure how customers can pay you</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between rounded-xl border border-slate-200/50 dark:border-slate-700/50 p-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30">
                              <span className="text-xl">💳</span>
                            </div>
                            <div>
                              <p className="font-medium text-slate-900 dark:text-slate-100">Stripe</p>
                              <p className="text-sm text-slate-500 dark:text-slate-400">Credit cards, Apple Pay, Google Pay</p>
                            </div>
                          </div>
                          <Badge variant="success">Connected</Badge>
                        </div>

                        <div className="flex items-center justify-between rounded-xl border border-slate-200/50 dark:border-slate-700/50 p-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 dark:bg-blue-900/30">
                              <span className="text-xl">🅿️</span>
                            </div>
                            <div>
                              <p className="font-medium text-slate-900 dark:text-slate-100">PayPal</p>
                              <p className="text-sm text-slate-500 dark:text-slate-400">PayPal, Venmo, PayPal Credit</p>
                            </div>
                          </div>
                          <Badge variant="outline">Not Connected</Badge>
                        </div>

                        <div className="flex items-center justify-between rounded-xl border border-slate-200/50 dark:border-slate-700/50 p-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-100 dark:bg-green-900/30">
                              <span className="text-xl">₿</span>
                            </div>
                            <div>
                              <p className="font-medium text-slate-900 dark:text-slate-100">Crypto</p>
                              <p className="text-sm text-slate-500 dark:text-slate-400">Bitcoin, Ethereum, USDC, and more</p>
                            </div>
                          </div>
                          <Badge variant="outline">Not Connected</Badge>
                        </div>

                        <div className="flex items-center justify-between rounded-xl border border-slate-200/50 dark:border-slate-700/50 p-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 dark:bg-amber-900/30">
                              <span className="text-xl">🏦</span>
                            </div>
                            <div>
                              <p className="font-medium text-slate-900 dark:text-slate-100">Bank Transfer</p>
                              <p className="text-sm text-slate-500 dark:text-slate-400">Direct bank transfers</p>
                            </div>
                          </div>
                          <Badge variant="success">Connected</Badge>
                        </div>
                      </div>

                      <Button variant="outline" className="w-full">
                        <Plus className="h-4 w-4 mr-2" />
                        Add Payment Method
                      </Button>
                    </CardContent>
                  </Card>
                )}

                {activeTab === "security" && (
                  <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                    <CardHeader>
                      <CardTitle>Security & Compliance</CardTitle>
                      <CardDescription>Manage your account security and compliance settings</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-4">
                        <div>
                          <Label className="font-medium text-slate-900 dark:text-slate-100">
                            Two-Factor Authentication
                          </Label>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            Add an extra layer of security to your account
                          </p>
                        </div>
                        <Switch
                          checked={settings.twoFactorAuth}
                          onCheckedChange={(checked) => setSettings({ ...settings, twoFactorAuth: checked })}
                        />
                      </div>

                      <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-4">
                        <div>
                          <Label className="font-medium text-slate-900 dark:text-slate-100">
                            Role Management
                          </Label>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            Control access permissions for team members
                          </p>
                        </div>
                        <Button variant="ghost" size="sm">
                          Manage Roles
                        </Button>
                      </div>

                      <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-4">
                        <div>
                          <Label className="font-medium text-slate-900 dark:text-slate-100">
                            Audit Logs
                          </Label>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            Track all actions and changes in your account
                          </p>
                        </div>
                        <Button variant="ghost" size="sm">
                          View Logs
                        </Button>
                      </div>

                      <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-4">
                        <div>
                          <Label className="font-medium text-slate-900 dark:text-slate-100">
                            Data Encryption
                          </Label>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            All data is encrypted at rest and in transit
                          </p>
                        </div>
                        <Badge variant="success">AES-256</Badge>
                      </div>

                      <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-4">
                        <div>
                          <Label className="font-medium text-slate-900 dark:text-slate-100">
                            GDPR & SOC2 Compliance
                          </Label>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            Fully compliant with GDPR and SOC2 Type II
                          </p>
                        </div>
                        <Badge variant="success">Compliant</Badge>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {activeTab === "notifications" && (
                  <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
                    <CardHeader>
                      <CardTitle>Notifications</CardTitle>
                      <CardDescription>Configure how you receive notifications</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-4">
                        <div>
                          <Label className="font-medium text-slate-900 dark:text-slate-100">
                            Email Notifications
                          </Label>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            Receive email notifications for invoice events
                          </p>
                        </div>
                        <Switch
                          checked={settings.emailNotifications}
                          onCheckedChange={(checked) => setSettings({ ...settings, emailNotifications: checked })}
                        />
                      </div>

                      <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-4">
                        <div>
                          <Label className="font-medium text-slate-900 dark:text-slate-100">
                            SMS Notifications
                          </Label>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            Receive SMS notifications for urgent invoice events
                          </p>
                        </div>
                        <Switch
                          checked={settings.smsNotifications}
                          onCheckedChange={(checked) => setSettings({ ...settings, smsNotifications: checked })}
                        />
                      </div>

                      <div className="flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-4">
                        <div>
                          <Label className="font-medium text-slate-900 dark:text-slate-100">
                            Payment Reminders
                          </Label>
                          <p className="text-sm text-slate-500 dark:text-slate-400">
                            Automatically send reminders for overdue invoices
                          </p>
                        </div>
                        <Switch
                          checked={settings.paymentReminders}
                          onCheckedChange={(checked) => setSettings({ ...settings, paymentReminders: checked })}
                        />
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Save Button */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  className="mt-6 flex justify-end gap-3"
                >
                  <Button variant="outline">
                    Cancel
                  </Button>
                  <Button variant="gradient">
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </Button>
                </motion.div>
              </motion.div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
