import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { DashboardStats } from "@/components/dashboard/dashboard-stats";
import { RevenueChart } from "@/components/dashboard/revenue-chart";
import { TaxSummary } from "@/components/dashboard/tax-summary";
import { RecentInvoices } from "@/components/dashboard/recent-invoices";
import { QuickActions } from "@/components/dashboard/quick-actions";
import { CustomerActivity } from "@/components/dashboard/customer-activity";

export default function DashboardPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen bg-slate-50/30 dark:bg-slate-900/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">
              Dashboard
            </h1>
            <p className="text-slate-600 dark:text-slate-400">
              Welcome back, Alex. Here's your invoicing overview.
            </p>
          </div>

          <DashboardStats />

          <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <RevenueChart />
            </div>
            <div>
              <TaxSummary />
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <RecentInvoices />
            </div>
            <div className="space-y-8">
              <QuickActions />
              <CustomerActivity />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
