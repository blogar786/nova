import {
  pgTable,
  text,
  timestamp,
  boolean,
  integer,
  numeric,
  jsonb,
  uuid,
  index,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

export const businesses = pgTable("businesses", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  website: text("website"),
  taxNumber: text("tax_number"),
  vatNumber: text("vat_number"),
  gstNumber: text("gst_number"),
  logoUrl: text("logo_url"),
  currency: text("currency").default("USD"),
  country: text("country"),
  template: text("template").default("modern"),
  brandColor: text("brand_color").default("#3b82f6"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const customers = pgTable("customers", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  billingAddress: text("billing_address"),
  shippingAddress: text("shipping_address"),
  taxNumber: text("tax_number"),
  vatNumber: text("vat_number"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const invoices = pgTable(
  "invoices",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: text("user_id").notNull(),
    businessId: uuid("business_id").references(() => businesses.id),
    customerId: uuid("customer_id").references(() => customers.id),
    invoiceNumber: text("invoice_number").notNull(),
    status: text("status").default("draft"),
    currency: text("currency").default("USD"),
    issueDate: timestamp("issue_date").defaultNow(),
    dueDate: timestamp("due_date"),
    purchaseOrderNumber: text("purchase_order_number"),
    referenceNumber: text("reference_number"),
    subtotal: numeric("subtotal", { precision: 12, scale: 2 }).default("0"),
    taxAmount: numeric("tax_amount", { precision: 12, scale: 2 }).default("0"),
    discountAmount: numeric("discount_amount", { precision: 12, scale: 2 }).default("0"),
    shippingAmount: numeric("shipping_amount", { precision: 12, scale: 2 }).default("0"),
    totalAmount: numeric("total_amount", { precision: 12, scale: 2 }).default("0"),
    taxType: text("tax_type").default("VAT"),
    taxRate: numeric("tax_rate", { precision: 5, scale: 2 }).default("0"),
    paymentTerms: text("payment_terms").default("NET_30"),
    paymentMethod: text("payment_method"),
    paymentLink: text("payment_link"),
    notes: text("notes"),
    terms: text("terms"),
    fieldConfig: jsonb("field_config"),
    template: text("template").default("modern"),
    aiGenerated: boolean("ai_generated").default(false),
    aiPrompt: text("ai_prompt"),
    errors: jsonb("errors"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => [
    index("invoices_user_id_idx").on(table.userId),
    index("invoices_status_idx").on(table.status),
    index("invoices_created_at_idx").on(table.createdAt),
  ],
);

export const invoiceItems = pgTable("invoice_items", {
  id: uuid("id").primaryKey().defaultRandom(),
  invoiceId: uuid("invoice_id").references(() => invoices.id, { onDelete: "cascade" }),
  description: text("description").notNull(),
  quantity: numeric("quantity", { precision: 10, scale: 2 }).notNull(),
  unitPrice: numeric("unit_price", { precision: 12, scale: 2 }).notNull(),
  taxRate: numeric("tax_rate", { precision: 5, scale: 2 }).default("0"),
  taxAmount: numeric("tax_amount", { precision: 12, scale: 2 }).default("0"),
  discount: numeric("discount", { precision: 12, scale: 2 }).default("0"),
  total: numeric("total", { precision: 12, scale: 2 }).notNull(),
  lineNumber: integer("line_number"),
});

export const templates = pgTable("templates", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  style: text("style").notNull(),
  previewImage: text("preview_image"),
  config: jsonb("config"),
  isPremium: boolean("is_premium").default(false),
  country: text("country"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const invoiceAnalytics = pgTable(
  "invoice_analytics",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    invoiceId: uuid("invoice_id").references(() => invoices.id, { onDelete: "cascade" }),
    event: text("event").notNull(),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => [index("invoice_analytics_invoice_id_idx").on(table.invoiceId)],
);

export const businessesRelations = relations(businesses, ({ many }) => ({
  invoices: many(invoices),
}));

export const customersRelations = relations(customers, ({ many }) => ({
  invoices: many(invoices),
}));

export const invoicesRelations = relations(invoices, ({ one, many }) => ({
  business: one(businesses, {
    fields: [invoices.businessId],
    references: [businesses.id],
  }),
  customer: one(customers, {
    fields: [invoices.customerId],
    references: [customers.id],
  }),
  items: many(invoiceItems),
  analytics: many(invoiceAnalytics),
}));

export const invoiceItemsRelations = relations(invoiceItems, ({ one }) => ({
  invoice: one(invoices, {
    fields: [invoiceItems.invoiceId],
    references: [invoices.id],
  }),
}));

export const invoiceAnalyticsRelations = relations(invoiceAnalytics, ({ one }) => ({
  invoice: one(invoices, {
    fields: [invoiceAnalytics.invoiceId],
    references: [invoices.id],
  }),
}));
