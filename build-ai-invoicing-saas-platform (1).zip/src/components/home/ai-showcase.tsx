"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, AlertTriangle, CheckCircle, TrendingUp, FileText, Zap } from "lucide-react";

const aiFeatures = [
  {
    title: "Prompt-Based Generation",
    description: "Create invoices using natural language. Example: 'Create invoice for Ali Raza selling 10 posture belts to Ahmed Trading Dubai.'",
    icon: Bot,
    gradient: "from-blue-500 to-purple-600",
    example: "Create invoice for Sarah Johnson selling 5 consulting hours at $150/hr to TechCorp NY",
  },
  {
    title: "AI Error Detection",
    description: "Automatically detect wrong calculations, duplicate invoice numbers, missing fields, invalid tax, and more before exporting.",
    icon: AlertTriangle,
    gradient: "from-amber-500 to-orange-600",
    checks: ["Wrong calculations", "Duplicate invoice numbers", "Missing fields", "Invalid tax", "Incorrect currency", "Missing customer details", "Missing VAT", "Missing payment info", "Duplicate products", "Broken formatting", "Missing legal info"],
  },
  {
    title: "AI Analytics & Predictions",
    description: "Revenue prediction, late payment prediction, tax estimation, cashflow forecasting, and business reports.",
    icon: TrendingUp,
    gradient: "from-emerald-500 to-teal-600",
    predictions: ["Revenue prediction", "Late payment prediction", "Tax estimation", "Cashflow prediction", "Business reports", "Expense reports", "Profit reports", "Monthly trends", "Yearly reports"],
  },
];

export function AIShowcaseSection() {
  return (
    <section className="py-20 sm:py-24 lg:py-32 bg-slate-50/50 dark:bg-slate-900/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-slate-200/50 dark:border-slate-700/50 bg-white/30 dark:bg-slate-800/30 px-4 py-2 text-sm backdrop-blur-xl">
            <Bot className="h-4 w-4 text-primary-600 dark:text-primary-400" />
            <span className="font-medium">Powered by AI</span>
          </div>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl mb-6">
            <span className="bg-gradient-to-r from-slate-900 to-slate-700 dark:from-slate-100 dark:to-slate-300 bg-clip-text text-transparent">
              Artificial Intelligence
            </span>{" "}
            <span className="bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
              at Work
            </span>
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-slate-600 dark:text-slate-300">
            Our AI doesn't just generate invoices — it thinks, detects errors, predicts outcomes, and automates everything.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          {aiFeatures.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
              >
                <Card className="group h-full border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30 hover:shadow-2xl transition-all duration-300">
                  <div className="p-6">
                    <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900 shadow-lg group-hover:scale-110 transition-transform duration-300">
                      <Icon className={`h-7 w-7 bg-gradient-to-br ${feature.gradient} bg-clip-text text-transparent`} />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-3 group-hover:text-primary-600 transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-300 mb-4 leading-relaxed">
                      {feature.description}
                    </p>

                    {feature.example && (
                      <div className="rounded-xl bg-slate-100/50 dark:bg-slate-800/50 p-3 mb-4">
                        <code className="text-xs text-slate-700 dark:text-slate-300">
                          {feature.example}
                        </code>
                      </div>
                    )}

                    {feature.checks && (
                      <div className="space-y-2">
                        <Badge variant="outline" className="text-xs">
                          Detection Checks
                        </Badge>
                        <div className="grid grid-cols-1 gap-1.5">
                          {feature.checks.map((check) => (
                            <div key={check} className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
                              <CheckCircle className="h-3 w-3 text-emerald-500" />
                              {check}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {feature.predictions && (
                      <div className="space-y-2">
                        <Badge variant="outline" className="text-xs">
                          AI Predictions
                        </Badge>
                        <div className="grid grid-cols-1 gap-1.5">
                          {feature.predictions.map((pred) => (
                            <div key={pred} className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
                              <TrendingUp className="h-3 w-3 text-primary-500" />
                              {pred}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
