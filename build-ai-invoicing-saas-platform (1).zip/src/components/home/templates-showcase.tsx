"use client";

import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { templates, templateCategories } from "@/lib/data/templates";
import { Sparkles, Star, Filter } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

export function TemplatesShowcase() {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredTemplates = selectedCategory === "All"
    ? templates.slice(0, 12)
    : templates.filter((t) => t.category === selectedCategory).slice(0, 12);

  return (
    <section className="py-20 sm:py-24 lg:py-32 bg-slate-50/50 dark:bg-slate-900/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl mb-6">
            <span className="bg-gradient-to-r from-slate-900 to-slate-700 dark:from-slate-100 dark:to-slate-300 bg-clip-text text-transparent">
              World's Largest Template Library
            </span>
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-slate-600 dark:text-slate-300">
            200+ professionally designed templates across 40+ industries and every country.
          </p>
        </motion.div>

        {/* Category filter */}
        <div className="mb-8 flex flex-wrap gap-2 justify-center">
          <Button
            variant={selectedCategory === "All" ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory("All")}
            className="mb-2"
          >
            All Templates
          </Button>
          {templateCategories.slice(0, 12).map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="mb-2"
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Template grid */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredTemplates.map((template, index) => (
            <motion.div
              key={template.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
            >
              <Card className="group overflow-hidden border-slate-200/50 dark:border-slate-700/50 bg-white dark:bg-slate-800/50 hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]">
                <div className="relative aspect-[3/2] overflow-hidden bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-700 dark:to-slate-800">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="mb-2 text-3xl font-bold text-slate-400 dark:text-slate-500">
                        {template.previewImage?.split("-")[0]?.charAt(0).toUpperCase() || "T"}
                      </div>
                      <div className="text-xs text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                        {template.category}
                      </div>
                    </div>
                  </div>
                  {template.isPremium && (
                    <Badge className="absolute top-2 right-2" variant="premium">
                      <Star className="h-3 w-3 mr-1" />
                      Premium
                    </Badge>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-black/50 to-transparent flex items-end">
                    <span className="text-xs text-white px-3 pb-1 font-medium">
                      {template.name}
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-slate-900 dark:text-slate-100">{template.name}</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{template.category}</p>
                  {template.country && (
                    <Badge variant="outline" className="mt-2 text-xs">
                      {template.country}
                    </Badge>
                  )}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-12 text-center"
        >
          <Link href="/templates">
            <Button variant="gradient" size="lg">
              <Sparkles className="h-5 w-5 mr-2" />
              Browse All 200+ Templates
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
