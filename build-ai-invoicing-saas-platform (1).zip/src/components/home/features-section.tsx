"use client";

import { motion } from "framer-motion";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Bot,
  FileCheck,
  Calculator,
  Globe2,
  Palette,
  Shield,
  Zap,
  BarChart3,
  Send,
  Download,
  RefreshCw,
  Bell,
  Search,
  QrCode,
  FileText,
  Users,
  Settings,
} from "lucide-react";

const features = [
  {
    title: "AI Invoice Generation",
    description: "Generate invoices using natural language prompts. Just describe what you need and AI creates everything.",
    icon: Bot,
    gradient: "from-blue-500 to-purple-600",
  },
  {
    title: "Smart Include/Exclude Builder",
    description: "Every invoice field has an ON/OFF toggle. Include only what you need, exclude what you don't.",
    icon: Settings,
    gradient: "from-purple-500 to-pink-600",
  },
  {
    title: "Automatic Tax Engine",
    description: "VAT, GST, Sales Tax, Withholding Tax, and Reverse Charge — automatically calculated based on country.",
    icon: Calculator,
    gradient: "from-emerald-500 to-teal-600",
  },
  {
    title: "AI Error Detection",
    description: "Automatically detect wrong calculations, duplicate numbers, missing fields, and invalid tax before exporting.",
    icon: FileCheck,
    gradient: "from-amber-500 to-orange-600",
  },
  {
    title: "Worldwide Support",
    description: "Support for every country, every currency, every tax system, and every language.",
    icon: Globe2,
    gradient: "from-cyan-500 to-blue-600",
  },
  {
    title: "200+ Premium Templates",
    description: "The world's largest invoice template library across 40+ industries and every country.",
    icon: Palette,
    gradient: "from-rose-500 to-pink-600",
  },
  {
    title: "Smart Branding",
    description: "Upload logos, choose colors, custom fonts, watermarks, and brand headers/footers.",
    icon: Palette,
    gradient: "from-indigo-500 to-purple-600",
  },
  {
    title: "Payment Integration",
    description: "Stripe, PayPal, Wise, Razorpay, Square, Apple Pay, Google Pay, Crypto, and more.",
    icon: Send,
    gradient: "from-violet-500 to-purple-600",
  },
  {
    title: "Invoice Tracking",
    description: "Real-time notifications when invoices are viewed, downloaded, paid, or overdue.",
    icon: BarChart3,
    gradient: "from-green-500 to-emerald-600",
  },
  {
    title: "Customer Portal",
    description: "Clients can view, pay, download, and comment on invoices in a secure portal.",
    icon: Users,
    gradient: "from-blue-500 to-cyan-600",
  },
  {
    title: "Automation",
    description: "Recurring invoices, auto reminders, late fees, and subscription billing.",
    icon: RefreshCw,
    gradient: "from-orange-500 to-red-600",
  },
  {
    title: "Enterprise Security",
    description: "2FA, role management, encryption, audit logs, GDPR, and SOC2 compliance.",
    icon: Shield,
    gradient: "from-slate-700 to-slate-900",
  },
];

export function FeaturesSection() {
  return (
    <section className="py-20 sm:py-24 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl mb-6">
            <span className="bg-gradient-to-r from-slate-900 to-slate-700 dark:from-slate-100 dark:to-slate-300 bg-clip-text text-transparent">
              Everything you need to
            </span>{" "}
            <span className="bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
              invoice smarter
            </span>
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-slate-600 dark:text-slate-300">
            One platform that eliminates manual data entry, reduces mistakes, automates calculations,
            and supports every invoice format used around the world.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="group h-full border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30 hover:shadow-xl hover:shadow-slate-200/50 dark:hover:shadow-slate-900/50 transition-all duration-300">
                  <CardHeader>
                    <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900 shadow-lg group-hover:scale-110 transition-transform duration-300">
                      <Icon className={`h-7 w-7 bg-gradient-to-br ${feature.gradient} bg-clip-text text-transparent`} />
                    </div>
                    <CardTitle className="text-xl group-hover:text-primary-600 transition-colors">
                      {feature.title}
                    </CardTitle>
                    <CardDescription className="text-slate-500 dark:text-slate-400">
                      {feature.description}
                    </CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
