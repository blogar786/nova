"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Play, Sparkles, Globe, Clock, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-20 sm:py-24 lg:py-32">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary-50/50 via-transparent to-secondary-50/50 dark:from-primary-950/20 dark:via-transparent dark:to-secondary-950/20" />
      <div className="absolute -top-24 -right-24 h-96 w-96 rounded-full bg-gradient-to-br from-primary-300/20 to-secondary-300/20 dark:from-primary-700/10 dark:to-secondary-700/10 blur-3xl" />
      <div className="absolute -bottom-24 -left-24 h-96 w-96 rounded-full bg-gradient-to-tr from-secondary-300/20 to-primary-300/20 dark:from-secondary-700/10 dark:to-primary-700/10 blur-3xl" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="mx-auto max-w-5xl text-center">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8 inline-flex items-center gap-2 rounded-full border border-slate-200/50 dark:border-slate-700/50 bg-white/30 dark:bg-slate-800/30 px-4 py-2 text-sm backdrop-blur-xl"
          >
            <Sparkles className="h-4 w-4 text-primary-600 dark:text-primary-400" />
            <span className="font-medium">AI-powered invoice generation for every business worldwide</span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl xl:text-7xl"
          >
            <span className="bg-gradient-to-r from-primary-600 via-secondary-600 to-primary-800 bg-clip-text text-transparent">
              AI Invoice Generator
            </span>{" "}
            for Every Business{" "}
            <span className="bg-gradient-to-r from-secondary-600 to-primary-600 bg-clip-text text-transparent">
              Worldwide
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mx-auto mt-8 max-w-3xl text-lg text-slate-600 dark:text-slate-300"
          >
            Create beautiful invoices in seconds with AI.
            <span className="block mt-2 font-medium text-slate-900 dark:text-slate-100">
              Every country. Every currency. Every tax system. Every invoice template.
            </span>
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link href="/generator">
              <Button variant="gradient" size="lg" className="group">
                Generate Invoice
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="group">
              <Play className="h-5 w-5 mr-2" />
              Watch Demo
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-3"
          >
            <div className="flex flex-col items-center">
              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
                <Globe className="h-6 w-6 text-primary-600 dark:text-primary-400" />
              </div>
              <p className="text-3xl font-bold text-slate-900 dark:text-slate-100">195+</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">Countries Supported</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
                <FileText className="h-6 w-6 text-primary-600 dark:text-primary-400" />
              </div>
              <p className="text-3xl font-bold text-slate-900 dark:text-slate-100">200+</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">Invoice Templates</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
                <Clock className="h-6 w-6 text-primary-600 dark:text-primary-400" />
              </div>
              <p className="text-3xl font-bold text-slate-900 dark:text-slate-100">3s</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">Average Generation Time</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
