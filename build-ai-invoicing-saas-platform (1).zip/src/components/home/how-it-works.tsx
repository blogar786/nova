"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

const steps = [
  {
    step: "01",
    title: "Enter Your Details",
    description: "Provide customer info, products/services, tax rates, and payment terms in seconds.",
    gradient: "from-primary-500 to-blue-600",
  },
  {
    step: "02",
    title: "AI Generates Invoice",
    description: "Our AI creates a professional invoice with automatic calculations and tax engine.",
    gradient: "from-secondary-500 to-purple-600",
  },
  {
    step: "03",
    title: "Smart Error Detection",
    description: "AI reviews for calculation errors, missing fields, and compliance issues before export.",
    gradient: "from-emerald-500 to-teal-600",
  },
  {
    step: "04",
    title: "Export & Send",
    description: "Download as PDF, Word, Excel, or share a payment link. Track everything in real-time.",
    gradient: "from-amber-500 to-orange-600",
  },
];

export function HowItWorksSection() {
  return (
    <section className="py-20 sm:py-24 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl mb-6">
            <span className="bg-gradient-to-r from-slate-900 to-slate-700 dark:from-slate-100 dark:to-slate-300 bg-clip-text text-transparent">
              How It Works
            </span>
          </h2>
          <p className="mx-auto max-w-3xl text-lg text-slate-600 dark:text-slate-300">
            Creating perfect invoices has never been easier.
          </p>
        </motion.div>

        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-px -translate-x-1/2 bg-slate-200 dark:bg-slate-700 hidden md:block" />

          <div className="space-y-12">
            {steps.map((step, index) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: index * 0.15 }}
                className={cn(
                  "relative flex items-center md:even:flex-row-reverse",
                  "md:gap-12 lg:gap-24",
                )}
              >
                <div className="absolute left-1/2 -translate-x-1/2 z-10 hidden md:block">
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-600 to-secondary-600 text-white shadow-xl shadow-primary-600/25">
                    <span className="text-2xl font-bold">{step.step}</span>
                  </div>
                </div>

                <div className="md:w-1/2">
                  <div className="mb-4 flex items-center gap-3 md:justify-start">
                    <div className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br",
                      step.gradient,
                      "text-white shadow-lg",
                    )}>
                      <span className="text-lg font-bold">{step.step}</span>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                      {step.title}
                    </h3>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                <div className="md:w-1/2" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
