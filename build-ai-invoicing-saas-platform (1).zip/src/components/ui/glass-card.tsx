import * as React from "react";
import { cn } from "@/lib/utils";

export interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  intensity?: "light" | "medium" | "heavy";
}

const GlassCard = React.forwardRef<HTMLDivElement, GlassCardProps>(
  ({ className, intensity = "medium", children, ...props }, ref) => {
    const intensityClasses = {
      light: "bg-white/5 dark:bg-slate-800/5 border-white/10 dark:border-slate-700/30",
      medium: "bg-white/10 dark:bg-slate-800/10 border-white/20 dark:border-slate-700/40",
      heavy: "bg-white/15 dark:bg-slate-800/15 border-white/30 dark:border-slate-700/50",
    };

    return (
      <div
        ref={ref}
        className={cn(
          "rounded-2xl border backdrop-blur-xl transition-all duration-300",
          "shadow-[0_8px_32px_0_rgba(31,38,135,0.37)]",
          intensityClasses[intensity],
          className,
        )}
        {...props}
      >
        {children}
      </div>
    );
  },
);
GlassCard.displayName = "GlassCard";

export { GlassCard };
