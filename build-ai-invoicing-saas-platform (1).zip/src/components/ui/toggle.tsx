import * as React from "react";
import { cn } from "@/lib/utils";

export interface ToggleProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  pressed?: boolean;
  variant?: "default" | "ghost";
  size?: "default" | "sm" | "lg";
}

const Toggle = React.forwardRef<HTMLButtonElement, ToggleProps>(
  ({ className, pressed = false, variant = "default", size = "default", ...props }, ref) => {
    const baseClasses = "inline-flex items-center justify-center rounded-xl text-sm font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50";

    const variantClasses = {
      default: pressed
        ? "bg-primary-600 text-white shadow-lg shadow-primary-600/25"
        : "bg-slate-100 text-slate-900 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700",
      ghost: pressed
        ? "bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-slate-100"
        : "hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-800 dark:hover:text-slate-100",
    };

    const sizeClasses = {
      default: "h-10 px-3",
      sm: "h-8 px-2",
      lg: "h-12 px-4",
    };

    return (
      <button
        type="button"
        ref={ref}
        aria-pressed={pressed}
        className={cn(baseClasses, variantClasses[variant], sizeClasses[size], className)}
        {...props}
      />
    );
  },
);
Toggle.displayName = "Toggle";

export { Toggle };
