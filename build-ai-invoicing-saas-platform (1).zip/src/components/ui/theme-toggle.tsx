"use client";

import * as React from "react";
import { Moon, Sun, Monitor } from "lucide-react";
import { cn } from "@/lib/utils";

type Theme = "light" | "dark" | "system";

export function ThemeToggle({ className }: { className?: string }) {
  const [theme, setTheme] = React.useState<Theme>("system");
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    const saved = localStorage.getItem("theme") as Theme | null;
    const initialTheme = saved || "system";
    setTheme(initialTheme);
    applyTheme(initialTheme);
    setMounted(true);
  }, []);

  function applyTheme(theme: Theme) {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else if (theme === "light") {
      root.classList.remove("dark");
    } else {
      const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      root.classList.toggle("dark", isDark);
    }
  }

  function handleThemeChange(newTheme: Theme) {
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    applyTheme(newTheme);
  }

  if (!mounted) {
    return (
      <div className={cn("h-10 w-10 rounded-xl bg-slate-200 dark:bg-slate-700 animate-pulse", className)} />
    );
  }

  const Icon = theme === "dark" ? Moon : theme === "light" ? Sun : Monitor;

  return (
    <div className={cn("relative", className)}>
      <button
        onClick={() => {
          const nextTheme: Theme = theme === "light" ? "dark" : theme === "dark" ? "system" : "light";
          handleThemeChange(nextTheme);
        }}
        className={cn(
          "relative flex h-10 w-10 items-center justify-center rounded-xl",
          "bg-white/10 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700",
          "hover:bg-slate-100 dark:hover:bg-slate-700/80 transition-all duration-300",
          "group",
        )}
        aria-label="Toggle theme"
      >
        <Sun className="h-5 w-5 text-amber-500 transition-all duration-300 group-hover:scale-110" />
        <Moon className="absolute h-5 w-5 text-slate-700 dark:text-slate-300 transition-all duration-300 group-hover:scale-110" />
        <Monitor className="absolute h-5 w-5 opacity-0 transition-all duration-300 group-hover:opacity-100" />
      </button>
    </div>
  );
}
