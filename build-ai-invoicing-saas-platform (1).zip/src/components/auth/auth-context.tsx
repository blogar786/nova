"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from "react";

interface User {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  imageUrl?: string;
  createdAt: Date;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, firstName?: string, lastName?: string) => Promise<void>;
  signOut: () => Promise<void>;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
}

// Simple mock auth for demo purposes
// In production, replace with Clerk: import { ClerkProvider, useAuth as useClerkAuth } from "@clerk/nextjs"
const DEMO_USER: User = {
  id: "user_123",
  email: "demo@invoicenova.com",
  firstName: "Alex",
  lastName: "Chen",
  imageUrl: "",
  createdAt: new Date(),
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const storedUser = localStorage.getItem("invoicenova_user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const signIn = async (email: string, password: string) => {
    setIsLoading(true);
    // Mock authentication - in production use Clerk
    const mockUser: User = {
      id: "user_" + Math.random().toString(36).substr(2, 9),
      email,
      firstName: email.split("@")[0],
      lastName: "",
      imageUrl: "",
      createdAt: new Date(),
    };
    setUser(mockUser);
    localStorage.setItem("invoicenova_user", JSON.stringify(mockUser));
    setIsLoading(false);
  };

  const signUp = async (email: string, password: string, firstName?: string, lastName?: string) => {
    setIsLoading(true);
    const mockUser: User = {
      id: "user_" + Math.random().toString(36).substr(2, 9),
      email,
      firstName: firstName || email.split("@")[0],
      lastName: lastName || "",
      imageUrl: "",
      createdAt: new Date(),
    };
    setUser(mockUser);
    localStorage.setItem("invoicenova_user", JSON.stringify(mockUser));
    setIsLoading(false);
  };

  const signOut = async () => {
    setUser(null);
    localStorage.removeItem("invoicenova_user");
  };

  // Auto-login demo user for preview
  useEffect(() => {
    if (!user && !isLoading) {
      const storedUser = localStorage.getItem("invoicenova_user");
      if (!storedUser) {
        // Auto-login as demo user for preview
        setUser(DEMO_USER);
        localStorage.setItem("invoicenova_user", JSON.stringify(DEMO_USER));
      }
    }
  }, [user, isLoading]);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        signIn,
        signUp,
        signOut,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
