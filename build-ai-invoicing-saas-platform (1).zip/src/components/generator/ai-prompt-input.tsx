"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Bot, Sparkles, Loader2, Send, History } from "lucide-react";

interface AIPromptInputProps {
  onGenerate: (prompt: string) => Promise<void>;
  isLoading: boolean;
}

const examplePrompts = [
  "Create invoice for Ali Raza selling 10 posture belts to Ahmed Trading Dubai",
  "Invoice for Sarah Johnson - 5 consulting hours at $150/hr, VAT 20%, due in 30 days",
  "Generate invoice for TechCorp - 3 software licenses at $299 each, 10% discount, USD",
  "Invoice for Digital Agency Pro - web design services $5,000, GST 10%, Australia",
];

export function AIPromptInput({ onGenerate, isLoading }: AIPromptInputProps) {
  const [prompt, setPrompt] = useState("");
  const [showExamples, setShowExamples] = useState(true);

  const handleSubmit = async () => {
    if (!prompt.trim()) return;
    await onGenerate(prompt);
  };

  const handleExampleClick = (example: string) => {
    setPrompt(example);
    setShowExamples(false);
  };

  return (
    <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
            <Bot className="h-5 w-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
              AI Invoice Generator
            </CardTitle>
            <CardDescription className="text-slate-500 dark:text-slate-400">
              Describe what you need in natural language and let AI create your invoice
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          placeholder="Create invoice for [customer] selling [quantity] [product/service] at [price]..."
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="min-h-[120px] resize-none border-slate-200 dark:border-slate-700 bg-white/50 dark:bg-slate-800/50 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:ring-primary-500/20"
          disabled={isLoading}
        />

        <AnimatePresence>
          {showExamples && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-3"
            >
              <div className="flex items-center gap-2">
                <History className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                <span className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  Example prompts:
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {examplePrompts.map((example, index) => (
                  <motion.button
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.1 * index }}
                    onClick={() => handleExampleClick(example)}
                    className="rounded-xl border border-slate-200/50 dark:border-slate-700/50 bg-white/30 dark:bg-slate-800/30 px-3 py-2 text-left text-sm text-slate-700 dark:text-slate-300 hover:bg-white/50 dark:hover:bg-slate-800/50 transition-all duration-200"
                  >
                    <Sparkles className="mr-1.5 h-3 w-3 inline" />
                    {example}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center justify-between pt-2">
          <Badge variant="outline" className="text-xs">
            <Bot className="h-3 w-3 mr-1" />
            Powered by OpenAI GPT-4
          </Badge>
          <Button
            onClick={handleSubmit}
            disabled={!prompt.trim() || isLoading}
            variant="gradient"
            className="min-w-[140px]"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Generate with AI
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
