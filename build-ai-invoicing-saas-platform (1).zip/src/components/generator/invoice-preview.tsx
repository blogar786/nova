"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Send, Printer, FileText, Eye, Share2 } from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Invoice, Business, Customer, InvoiceItem } from "@/lib/types";

interface InvoicePreviewProps {
  invoice: any;
  business: any;
  customer: any;
  items: InvoiceItem[];
  fieldConfig: Record<string, boolean>;
  onExport: (format: string) => void;
}

export function InvoicePreview({ invoice, business, customer, items, fieldConfig, onExport }: InvoicePreviewProps) {
  const showField = (key: string) => fieldConfig[key] ?? true;

  const subtotal = items.reduce((sum, item) => sum + (item.total || 0), 0);
  const taxAmount = items.reduce((sum, item) => sum + (item.taxAmount || 0), 0);
  const total = subtotal + taxAmount + (invoice.shippingAmount || 0) - (invoice.discountAmount || 0);

  return (
    <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
              <FileText className="h-5 w-5 text-primary-600 dark:text-primary-400" />
            </div>
            <div>
              <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                Live Preview
              </CardTitle>
              <CardDescription className="text-slate-500 dark:text-slate-400">
                Real-time invoice preview
              </CardDescription>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => onExport("pdf")}>
              <Download className="h-4 w-4 mr-1" />
              PDF
            </Button>
            <Button variant="ghost" size="sm" onClick={() => onExport("print")}>
              <Printer className="h-4 w-4 mr-1" />
              Print
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="max-h-[600px] overflow-y-auto rounded-xl border border-slate-200/50 dark:border-slate-700/50 bg-white dark:bg-slate-800/50 p-8">
          {/* Header */}
          <div className="flex justify-between items-start mb-8">
            <div>
              {showField("companyLogo") && (
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
                  <span className="text-2xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
                    {business?.name?.charAt(0) || "N"}
                  </span>
                </div>
              )}
              {showField("businessAddress") && (
                <div className="space-y-1 text-sm text-slate-600 dark:text-slate-300">
                  <p className="font-bold text-slate-900 dark:text-slate-100">{business?.name || "Your Business"}</p>
                  {business?.address && <p>{business.address}</p>}
                  {showField("phone") && business?.phone && <p>{business.phone}</p>}
                  {showField("email") && business?.email && <p>{business.email}</p>}
                  {showField("website") && business?.website && <p>{business.website}</p>}
                </div>
              )}
            </div>

            <div className="text-right">
              <h2 className="text-3xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent mb-2">
                INVOICE
              </h2>
              {showField("invoiceNumber") && (
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  <span className="font-medium">Invoice #:</span> {invoice.invoiceNumber || "INV-2024-0001"}
                </p>
              )}
              {showField("issueDate") && (
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  <span className="font-medium">Issue Date:</span> {formatDate(invoice.issueDate || new Date())}
                </p>
              )}
              {showField("dueDate") && (
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  <span className="font-medium">Due Date:</span> {formatDate(invoice.dueDate || new Date())}
                </p>
              )}
            </div>
          </div>

          {/* Tax Numbers */}
          {showField("taxNumber") && business?.taxNumber && (
            <div className="mb-4 text-sm text-slate-600 dark:text-slate-300">
              Tax Number: {business.taxNumber}
            </div>
          )}
          {showField("vatNumber") && business?.vatNumber && (
            <div className="mb-4 text-sm text-slate-600 dark:text-slate-300">
              VAT Number: {business.vatNumber}
            </div>
          )}

          {/* Bill To */}
          <div className="mb-8">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-2">
              Bill To:
            </h3>
            <div className="text-sm text-slate-600 dark:text-slate-300">
              <p className="font-medium text-slate-900 dark:text-slate-100">{customer?.name || "Customer Name"}</p>
              {customer?.address && <p>{customer.address}</p>}
              {showField("customerAddress") && customer?.email && <p>{customer.email}</p>}
              {showField("customerAddress") && customer?.phone && <p>{customer.phone}</p>}
            </div>
          </div>

          {/* Items Table */}
          <div className="mb-8 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="text-left py-3 font-semibold text-slate-900 dark:text-slate-100">Description</th>
                  <th className="text-right py-3 font-semibold text-slate-900 dark:text-slate-100">Qty</th>
                  <th className="text-right py-3 font-semibold text-slate-900 dark:text-slate-100">Unit Price</th>
                  <th className="text-right py-3 font-semibold text-slate-900 dark:text-slate-100">Tax</th>
                  <th className="text-right py-3 font-semibold text-slate-900 dark:text-slate-100">Total</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={index} className="border-b border-slate-200/50 dark:border-slate-700/50">
                    <td className="py-3 text-slate-700 dark:text-slate-300">{item.description || `Item ${index + 1}`}</td>
                    <td className="text-right py-3 text-slate-700 dark:text-slate-300">{item.quantity}</td>
                    <td className="text-right py-3 text-slate-700 dark:text-slate-300">{formatCurrency(item.unitPrice, invoice.currency || "USD")}</td>
                    <td className="text-right py-3 text-slate-700 dark:text-slate-300">{item.taxRate}%</td>
                    <td className="text-right py-3 font-medium text-slate-900 dark:text-slate-100">{formatCurrency(item.total, invoice.currency || "USD")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="flex justify-end mb-8">
            <div className="w-64 space-y-2">
              {showField("subtotal") && (
                <div className="flex justify-between py-2 border-b border-slate-200 dark:border-slate-700">
                  <span className="text-slate-600 dark:text-slate-300">Subtotal:</span>
                  <span className="font-medium text-slate-900 dark:text-slate-100">{formatCurrency(subtotal, invoice.currency || "USD")}</span>
                </div>
              )}
              {showField("discount") && invoice.discountAmount > 0 && (
                <div className="flex justify-between py-2 border-b border-slate-200 dark:border-slate-700">
                  <span className="text-slate-600 dark:text-slate-300">Discount:</span>
                  <span className="font-medium text-red-500">-{formatCurrency(invoice.discountAmount, invoice.currency || "USD")}</span>
                </div>
              )}
              {showField("shippingCharges") && invoice.shippingAmount > 0 && (
                <div className="flex justify-between py-2 border-b border-slate-200 dark:border-slate-700">
                  <span className="text-slate-600 dark:text-slate-300">Shipping:</span>
                  <span className="font-medium text-slate-900 dark:text-slate-100">{formatCurrency(invoice.shippingAmount, invoice.currency || "USD")}</span>
                </div>
              )}
              {showField("taxBreakdown") && (
                <div className="flex justify-between py-2 border-b border-slate-200 dark:border-slate-700">
                  <span className="text-slate-600 dark:text-slate-300">Tax ({invoice.taxRate || 0}%):</span>
                  <span className="font-medium text-slate-900 dark:text-slate-100">{formatCurrency(taxAmount, invoice.currency || "USD")}</span>
                </div>
              )}
              <div className="flex justify-between py-3 border-t-2 border-slate-900 dark:border-slate-100">
                <span className="text-lg font-bold text-slate-900 dark:text-slate-100">Total:</span>
                <span className="text-2xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
                  {formatCurrency(total, invoice.currency || "USD")}
                </span>
              </div>
            </div>
          </div>

          {/* Payment & Notes */}
          {showField("paymentLink") && (
            <div className="mb-6">
              <Button variant="gradient" size="sm">
                Pay Now
              </Button>
            </div>
          )}

          {showField("notes") && invoice.notes && (
            <div className="mb-4">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-1">Notes:</h4>
              <p className="text-sm text-slate-600 dark:text-slate-300">{invoice.notes}</p>
            </div>
          )}

          {showField("termsAndConditions") && (
            <div className="mb-4">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-1">Terms & Conditions:</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Payment is due within {invoice.paymentTerms || "30"} days. Late payments may incur additional fees.
              </p>
            </div>
          )}

          {showField("signature") && (
            <div className="mt-8 pt-8 border-t border-slate-200 dark:border-slate-700">
              <p className="text-sm text-slate-600 dark:text-slate-300 mb-8">
                ___________________________<br />
                {business?.name || "Authorized Signature"}
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
