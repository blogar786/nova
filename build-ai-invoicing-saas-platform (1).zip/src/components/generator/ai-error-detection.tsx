"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle, XCircle, Info, RefreshCw } from "lucide-react";
import { AIError } from "@/lib/types";

interface AIErrorDetectionProps {
  errors: AIError[];
  onFix: (error: AIError) => void;
  onRecheck: () => void;
  isChecking: boolean;
}

const severityConfig = {
  high: { icon: XCircle, color: "text-red-500", bg: "bg-red-500/10", label: "Critical" },
  medium: { icon: AlertTriangle, color: "text-amber-500", bg: "bg-amber-500/10", label: "Warning" },
  low: { icon: Info, color: "text-blue-500", bg: "bg-blue-500/10", label: "Info" },
};

export function AIErrorDetection({ errors, onFix, onRecheck, isChecking }: AIErrorDetectionProps) {
  const highErrors = errors.filter((e) => e.severity === "high");
  const mediumErrors = errors.filter((e) => e.severity === "medium");
  const lowErrors = errors.filter((e) => e.severity === "low");

  return (
    <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
              <AlertTriangle className="h-5 w-5 text-primary-600 dark:text-primary-400" />
            </div>
            <div>
              <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                AI Error Detection
              </CardTitle>
              <CardDescription className="text-slate-500 dark:text-slate-400">
                {errors.length === 0
                  ? "No issues detected. Your invoice is ready to export."
                  : `${errors.length} issue${errors.length === 1 ? "" : "s"} detected. Review before exporting.`}
              </CardDescription>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onRecheck} disabled={isChecking}>
            {isChecking ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {errors.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-3 rounded-xl bg-emerald-500/10 p-4 text-emerald-600 dark:text-emerald-400"
          >
            <CheckCircle className="h-5 w-5" />
            <span className="text-sm font-medium">
              All checks passed! Your invoice is ready to export.
            </span>
          </motion.div>
        ) : (
          <div className="space-y-3">
            {/* High severity */}
            <AnimatePresence>
              {highErrors.map((error, index) => (
                <ErrorItem key={`high-${index}`} error={error} onFix={onFix} index={index} />
              ))}
            </AnimatePresence>

            {/* Medium severity */}
            {mediumErrors.map((error, index) => (
              <ErrorItem key={`medium-${index}`} error={error} onFix={onFix} index={index + highErrors.length} />
            ))}

            {/* Low severity */}
            {lowErrors.map((error, index) => (
              <ErrorItem key={`low-${index}`} error={error} onFix={onFix} index={index + highErrors.length + mediumErrors.length} />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ErrorItem({ error, onFix, index }: { error: AIError; onFix: (error: AIError) => void; index: number }) {
  const config = severityConfig[error.severity];
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      className={`rounded-xl border p-4 ${config.bg} border-slate-200/50 dark:border-slate-700/50`}
    >
      <div className="flex items-start gap-3">
        <Icon className={`h-5 w-5 ${config.color} flex-shrink-0 mt-0.5`} />
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <Badge variant={error.severity === "high" ? "destructive" : error.severity === "medium" ? "warning" : "default"} className="text-xs">
              {config.label}
            </Badge>
            <span className="text-sm font-medium text-slate-900 dark:text-slate-100">
              {error.field}
            </span>
          </div>
          <p className="text-sm text-slate-700 dark:text-slate-300 mb-1">
            {error.message}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            💡 {error.suggestion}
          </p>
        </div>
        <Button variant="ghost" size="sm" onClick={() => onFix(error)}>
          Fix
        </Button>
      </div>
    </motion.div>
  );
}
