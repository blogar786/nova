"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, Settings, Check, X } from "lucide-react";
import { fieldToggles, fieldCategories } from "@/lib/data/field-toggles";
import { useState } from "react";

interface FieldTogglesProps {
  fieldConfig: Record<string, boolean>;
  onChange: (config: Record<string, boolean>) => void;
}

export function FieldToggles({ fieldConfig, onChange }: FieldTogglesProps) {
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>(
    fieldCategories.reduce((acc, cat) => ({ ...acc, [cat]: true }), {})
  );

  const toggleField = (key: string) => {
    onChange({ ...fieldConfig, [key]: !fieldConfig[key] });
  };

  const toggleCategory = (category: string) => {
    setExpandedCategories({ ...expandedCategories, [category]: !expandedCategories[category] });
  };

  const toggleAllInCategory = (category: string, turnOn: boolean) => {
    const newConfig = { ...fieldConfig };
    fieldToggles
      .filter((f) => f.category === category)
      .forEach((f) => {
        newConfig[f.key] = turnOn;
      });
    onChange(newConfig);
  };

  const allOn = Object.values(fieldConfig).every(Boolean);
  const allOff = Object.values(fieldConfig).every((v) => !v);

  return (
    <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
              <Settings className="h-5 w-5 text-primary-600 dark:text-primary-400" />
            </div>
            <div>
              <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                Smart Include / Exclude Builder
              </CardTitle>
              <CardDescription className="text-slate-500 dark:text-slate-400">
                Toggle every invoice field ON or OFF
              </CardDescription>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => toggleAllInCategory("", true)}
              className="text-xs"
              title="Enable all fields"
            >
              <Check className="h-3 w-3 mr-1" />
              All On
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => toggleAllInCategory("", false)}
              className="text-xs"
              title="Disable all fields"
            >
              <X className="h-3 w-3 mr-1" />
              All Off
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="mb-4 flex items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 p-3">
          <Badge variant={allOn ? "success" : allOff ? "warning" : "secondary"} className="text-xs">
            {allOn ? "All fields enabled" : allOff ? "All fields disabled" : "Custom selection"}
          </Badge>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            {Object.values(fieldConfig).filter(Boolean).length} / {fieldToggles.length} fields enabled
          </span>
        </div>

        {fieldCategories.map((category) => (
          <div key={category} className="space-y-2">
            <button
              onClick={() => toggleCategory(category)}
              className="flex w-full items-center justify-between rounded-xl bg-slate-50 dark:bg-slate-800/50 px-4 py-2.5 text-left transition-colors hover:bg-slate-100 dark:hover:bg-slate-700/50"
            >
              <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                {category}
              </span>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  {fieldToggles.filter((f) => f.category === category && fieldConfig[f.key]).length}
                  /{fieldToggles.filter((f) => f.category === category).length}
                </Badge>
                {expandedCategories[category] ? (
                  <ChevronDown className="h-4 w-4 text-slate-500" />
                ) : (
                  <ChevronRight className="h-4 w-4 text-slate-500" />
                )}
              </div>
            </button>

            <AnimatePresence initial={false}>
              {expandedCategories[category] && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="ml-4 space-y-2 border-l-2 border-slate-200 dark:border-slate-700 pl-4">
                    {fieldToggles
                      .filter((f) => f.category === category)
                      .map((field) => (
                        <motion.div
                          key={field.key}
                          className="flex items-center justify-between rounded-xl bg-white/30 dark:bg-slate-800/30 px-3 py-2"
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <div className="flex-1">
                            <Label className="text-sm font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                              {field.label}
                            </Label>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                              {field.description}
                            </p>
                          </div>
                          <Switch
                            checked={fieldConfig[field.key] ?? field.defaultOn}
                            onCheckedChange={() => toggleField(field.key)}
                            className="ml-3"
                          />
                        </motion.div>
                      ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
