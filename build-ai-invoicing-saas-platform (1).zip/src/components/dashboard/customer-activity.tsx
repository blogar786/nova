"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Eye, Download, CheckCircle, Clock } from "lucide-react";

const activity = [
  { id: 1, customer: "TechCorp Solutions", action: "Viewed invoice INV-2024-0012", time: "2 hours ago", icon: Eye, status: "viewed" },
  { id: 2, customer: "Ahmed Trading Dubai", action: "Downloaded invoice INV-2024-0013", time: "5 hours ago", icon: Download, status: "downloaded" },
  { id: 3, customer: "Sarah Johnson", action: "Paid invoice INV-2024-0014", time: "1 day ago", icon: CheckCircle, status: "paid" },
  { id: 4, customer: "Digital Agency Pro", action: "Invoice sent INV-2024-0015", time: "2 days ago", icon: Clock, status: "sent" },
  { id: 5, customer: "Global Imports Ltd", action: "Viewed invoice INV-2024-0016", time: "3 days ago", icon: Eye, status: "viewed" },
];

const statusColors = {
  viewed: "bg-blue-500/10 text-blue-500",
  downloaded: "bg-purple-500/10 text-purple-500",
  paid: "bg-emerald-500/10 text-emerald-500",
  sent: "bg-amber-500/10 text-amber-500",
};

export function CustomerActivity() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6 }}
    >
      <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
            Customer Activity
          </CardTitle>
          <CardDescription className="text-slate-500 dark:text-slate-400">
            Recent client interactions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activity.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.1 * index }}
                  className="flex items-start gap-3"
                >
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900">
                    <User className="h-5 w-5 text-slate-600 dark:text-slate-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                        {item.customer}
                      </p>
                      <Badge variant="outline" className={`text-xs ${statusColors[item.status as keyof typeof statusColors]}`}>
                        {item.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                      {item.action}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">
                      {item.time}
                    </p>
                  </div>
                  <div className="flex-shrink-0">
                    <Icon className={`h-4 w-4 ${
                      item.status === "paid" ? "text-emerald-500" :
                      item.status === "viewed" ? "text-blue-500" :
                      item.status === "downloaded" ? "text-purple-500" :
                      "text-amber-500"
                    }`} />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
