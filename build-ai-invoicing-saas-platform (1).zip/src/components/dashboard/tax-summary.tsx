"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/utils";
import { FileText } from "lucide-react";

const taxData = [
  { type: "VAT (20%)", amount: 8420.5, rate: 20, color: "from-blue-500 to-cyan-600" },
  { type: "GST (10%)", amount: 1200.0, rate: 10, color: "from-emerald-500 to-teal-600" },
  { type: "Sales Tax (7.5%)", amount: 980.5, rate: 7.5, color: "from-amber-500 to-orange-600" },
  { type: "Withholding Tax (15%)", amount: 450.0, rate: 15, color: "from-purple-500 to-pink-600" },
];

const statusData = [
  { label: "Draft", count: 8, color: "bg-slate-500/10 text-slate-500" },
  { label: "Sent", count: 15, color: "bg-blue-500/10 text-blue-500" },
  { label: "Paid", count: 127, color: "bg-emerald-500/10 text-emerald-500" },
  { label: "Pending", count: 23, color: "bg-amber-500/10 text-amber-500" },
  { label: "Overdue", count: 5, color: "bg-red-500/10 text-red-500" },
];

export function TaxSummary() {
  const totalTax = taxData.reduce((sum, t) => sum + t.amount, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
    >
      <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
            Tax Summary
          </CardTitle>
          <CardDescription className="text-slate-500 dark:text-slate-400">
            Total collected: {formatCurrency(totalTax)}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {taxData.map((tax, index) => (
            <motion.div
              key={tax.type}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.1 * index }}
              className="space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`h-3 w-3 rounded-full bg-gradient-to-r ${tax.color}`} />
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    {tax.type}
                  </span>
                </div>
                <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  {formatCurrency(tax.amount)}
                </span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                <div
                  className={`h-full rounded-full bg-gradient-to-r ${tax.color}`}
                  style={{ width: `${(tax.amount / totalTax) * 100}%` }}
                />
              </div>
            </motion.div>
          ))}

          <div className="mt-6 pt-4 border-t border-slate-200/50 dark:border-slate-700/50">
            <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">
              Invoice Status Overview
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {statusData.map((status) => (
                <div
                  key={status.label}
                  className={`flex items-center justify-between rounded-xl px-3 py-2 ${status.color.replace("text-", "bg-").replace("/10", "/5")} dark:bg-slate-800/50`}
                >
                  <span className="text-sm text-slate-700 dark:text-slate-300">
                    {status.label}
                  </span>
                  <Badge variant="outline" className="text-xs">
                    {status.count}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
