"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  DollarSign,
  CheckCircle,
  Clock,
  Send,
  AlertCircle,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { formatCurrency } from "@/lib/utils";

const stats = [
  {
    title: "Total Revenue",
    value: formatCurrency(45280.5),
    change: "+12.5% from last month",
    changeType: "increase",
    icon: DollarSign,
    gradient: "from-emerald-500 to-teal-600",
    bgGradient: "from-emerald-500/10 to-teal-600/10",
  },
  {
    title: "Paid Invoices",
    value: "127",
    change: "+8.2% from last month",
    changeType: "increase",
    icon: CheckCircle,
    gradient: "from-blue-500 to-cyan-600",
    bgGradient: "from-blue-500/10 to-cyan-600/10",
  },
  {
    title: "Pending Invoices",
    value: "23",
    change: "-3.1% from last month",
    changeType: "decrease",
    icon: Clock,
    gradient: "from-amber-500 to-orange-600",
    bgGradient: "from-amber-500/10 to-orange-600/10",
  },
  {
    title: "Overdue Invoices",
    value: "5",
    change: "+2 from last month",
    changeType: "increase",
    icon: AlertCircle,
    gradient: "from-red-500 to-rose-600",
    bgGradient: "from-red-500/10 to-rose-600/10",
  },
];

export function DashboardStats() {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        const TrendIcon = stat.changeType === "increase" ? TrendingUp : TrendingDown;
        return (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="h-full border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30 hover:shadow-lg transition-all duration-300 group">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  {stat.title}
                </CardTitle>
                <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${stat.bgGradient} group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className={`h-5 w-5 bg-gradient-to-br ${stat.gradient} bg-clip-text text-transparent`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                  {stat.value}
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <Badge
                    variant={stat.changeType === "increase" ? "success" : "warning"}
                    className="text-xs"
                  >
                    <TrendIcon className="h-3 w-3 mr-1" />
                    {stat.change}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}
