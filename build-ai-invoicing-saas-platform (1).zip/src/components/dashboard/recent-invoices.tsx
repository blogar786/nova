"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatCurrency, formatDate, getStatusColor, getStatusLabel } from "@/lib/utils";
import { FileText, Download, Send, MoreHorizontal, Eye } from "lucide-react";
import Link from "next/link";

const invoices = [
  {
    id: "inv_001",
    invoiceNumber: "INV-2024-0012",
    customer: "TechCorp Solutions",
    date: "2024-12-15",
    dueDate: "2025-01-15",
    amount: 4500.0,
    status: "paid",
    items: 3,
  },
  {
    id: "inv_002",
    invoiceNumber: "INV-2024-0013",
    customer: "Ahmed Trading Dubai",
    date: "2024-12-20",
    dueDate: "2025-01-20",
    amount: 12500.0,
    status: "pending",
    items: 10,
  },
  {
    id: "inv_003",
    invoiceNumber: "INV-2024-0014",
    customer: "Sarah Johnson Consulting",
    date: "2024-12-18",
    dueDate: "2025-01-18",
    amount: 3200.0,
    status: "overdue",
    items: 2,
  },
  { id: "inv_004", invoiceNumber: "INV-2024-0015", customer: "Digital Agency Pro", date: "2024-12-22", dueDate: "2025-01-22", amount: 8750.0, status: "sent", items: 5 },
  { id: "inv_005", invoiceNumber: "INV-2024-0016", customer: "Global Imports Ltd", date: "2024-12-25", dueDate: "2025-01-25", amount: 15600.0, status: "draft", items: 8 },
];

export function RecentInvoices() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                Recent Invoices
              </CardTitle>
              <CardDescription className="text-slate-500 dark:text-slate-400">
                Your latest 5 invoices
              </CardDescription>
            </div>
            <Link href="/dashboard/invoices">
              <Button variant="ghost" size="sm">
                View All
                <MoreHorizontal className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {invoices.map((invoice, index) => (
              <motion.div
                key={invoice.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.1 * index }}
                className="group flex items-center justify-between rounded-xl border border-slate-200/50 dark:border-slate-700/50 p-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all duration-200"
              >
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 dark:from-primary-900/30 dark:to-secondary-900/30">
                    <FileText className="h-6 w-6 text-primary-600 dark:text-primary-400" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-slate-900 dark:text-slate-100">
                        {invoice.invoiceNumber}
                      </p>
                      <Badge className={getStatusColor(invoice.status)} variant="secondary">
                        {getStatusLabel(invoice.status)}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      {invoice.customer} • {invoice.items} items
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-500">
                      Due: {formatDate(invoice.dueDate)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="font-semibold text-slate-900 dark:text-slate-100">
                      {formatCurrency(invoice.amount)}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
