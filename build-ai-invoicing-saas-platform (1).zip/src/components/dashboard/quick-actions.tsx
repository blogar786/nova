"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Plus,
  FileText,
  Send,
  RefreshCw,
  Bell,
  BarChart3,
  Settings,
  Users,
  Sparkles,
} from "lucide-react";
import Link from "next/link";

const actions = [
  { name: "New Invoice", icon: Plus, href: "/generator", gradient: "from-primary-500 to-blue-600" },
  { name: "AI Generate", icon: Sparkles, href: "/generator", gradient: "from-secondary-500 to-purple-600" },
  { name: "Send Reminder", icon: Bell, href: "#", gradient: "from-amber-500 to-orange-600" },
  { name: "Recurring Setup", icon: RefreshCw, href: "#", gradient: "from-emerald-500 to-teal-600" },
  { name: "Customer Portal", icon: Users, href: "#", gradient: "from-cyan-500 to-blue-600" },
  { name: "Analytics", icon: BarChart3, href: "/dashboard/analytics", gradient: "from-purple-500 to-pink-600" },
  { name: "Templates", icon: FileText, href: "/templates", gradient: "from-rose-500 to-pink-600" },
  { name: "Settings", icon: Settings, href: "#", gradient: "from-slate-600 to-slate-800" },
];

export function QuickActions() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
    >
      <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {actions.map((action, index) => {
              const Icon = action.icon;
              return (
                <motion.div
                  key={action.name}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: 0.05 * index }}
                >
                  <Link href={action.href}>
                    <Button
                      variant="outline"
                      className="w-full h-auto py-4 justify-start gap-3 group border-slate-200/50 dark:border-slate-700/50 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                    >
                      <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${action.gradient} text-white shadow-lg group-hover:scale-110 transition-transform`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <span className="text-sm font-medium text-slate-700 dark:text-slate-300 group-hover:text-slate-900 dark:group-hover:text-slate-100">
                        {action.name}
                      </span>
                    </Button>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
