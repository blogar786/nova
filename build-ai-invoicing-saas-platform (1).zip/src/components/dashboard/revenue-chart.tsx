"use client";

import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { formatCurrency } from "@/lib/utils";

const data = [
  { month: "Jan", income: 2400, expenses: 800 },
  { month: "Feb", income: 3200, expenses: 1200 },
  { month: "Mar", income: 2800, expenses: 900 },
  { month: "Apr", income: 4200, expenses: 1100 },
  { month: "May", income: 3800, expenses: 1000 },
  { month: "Jun", income: 4800, expenses: 1300 },
  { month: "Jul", income: 5200, expenses: 1400 },
  { month: "Aug", income: 4600, expenses: 1200 },
  { month: "Sep", income: 5800, expenses: 1500 },
  { month: "Oct", income: 6200, expenses: 1600 },
  { month: "Nov", income: 5400, expenses: 1400 },
  { month: "Dec", income: 7200, expenses: 1800 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-xl border border-slate-200/50 dark:border-slate-700/50 bg-white dark:bg-slate-800 p-3 shadow-xl">
        <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{label}</p>
        <div className="mt-1 space-y-1">
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Income: <span className="font-semibold text-emerald-500">{formatCurrency(payload[0].value)}</span>
          </p>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Expenses: <span className="font-semibold text-red-500">{formatCurrency(payload[1].value)}</span>
          </p>
        </div>
      </div>
    );
  }
  return null;
};

export function RevenueChart() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-800/30">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
            Monthly Income & Expenses
          </CardTitle>
          <CardDescription className="text-slate-500 dark:text-slate-400">
            Track your revenue over the past 12 months
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
                <XAxis
                  dataKey="month"
                  tick={{ fill: "currentColor", fontSize: 12 }}
                  tickLine={false}
                  axisLine={false}
                  className="text-slate-500 dark:text-slate-400"
                />
                <YAxis
                  tick={{ fill: "currentColor", fontSize: 12 }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(value) => `$${value}`}
                  className="text-slate-500 dark:text-slate-400"
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="income"
                  stroke="#10b981"
                  strokeWidth={2}
                  fill="url(#incomeGradient)"
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Area
                  type="monotone"
                  dataKey="expenses"
                  stroke="#ef4444"
                  strokeWidth={2}
                  fill="url(#expenseGradient)"
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
