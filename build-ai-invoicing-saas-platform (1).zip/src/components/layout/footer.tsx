import Link from "next/link";
import { Sparkles } from "lucide-react";

const footerLinks = [
  { name: "Product", links: [{ name: "Features", href: "#" }, { name: "Templates", href: "/templates" }, { name: "Pricing", href: "#" }, { name: "API", href: "#" }] },
  { name: "Company", links: [{ name: "About", href: "#" }, { name: "Blog", href: "#" }, { name: "Careers", href: "#" }, { name: "Contact", href: "#" }] },
  { name: "Resources", links: [{ name: "Help Center", href: "#" }, { name: "Documentation", href: "#" }, { name: "Community", href: "#" }, { name: "Status", href: "#" }] },
  { name: "Legal", links: [{ name: "Privacy", href: "#" }, { name: "Terms", href: "#" }, { name: "Security", href: "#" }, { name: "GDPR", href: "#" }] },
];

export function Footer() {
  return (
    <footer className="border-t border-slate-200/50 dark:border-slate-700/50 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl mt-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-5">
          <div>
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary-600 to-secondary-600">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
                InvoiceNova
              </span>
            </Link>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              The world's most advanced AI-powered invoice generation platform.
            </p>
          </div>
          {footerLinks.map((category) => (
            <div key={category.name}>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-4">
                {category.name}
              </h3>
              <ul className="space-y-3">
                {category.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-sm text-slate-500 dark:text-slate-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 pt-8 border-t border-slate-200/50 dark:border-slate-700/50">
          <p className="text-center text-sm text-slate-500 dark:text-slate-400">
            © {new Date().getFullYear()} InvoiceNova. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
