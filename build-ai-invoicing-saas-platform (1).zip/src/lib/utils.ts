import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number | string, currency: string = "USD"): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(num);
}

export function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(d);
}

export function generateInvoiceNumber(): string {
  const year = new Date().getFullYear();
  const random = Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, "0");
  return `INV-${year}-${random}`;
}

export function calculateInvoiceTotals(items: any[], taxRate: number, discount: number, shipping: number) {
  const subtotal = items.reduce((sum, item) => sum + (parseFloat(item.total) || 0), 0);
  const taxAmount = subtotal * (taxRate / 100);
  const total = subtotal - discount + taxAmount + shipping;
  return {
    subtotal: subtotal.toFixed(2),
    taxAmount: taxAmount.toFixed(2),
    discountAmount: discount.toFixed(2),
    shippingAmount: shipping.toFixed(2),
    total: total.toFixed(2),
  };
}

export function getDaysOverdue(dueDate: Date | string): number {
  const due = typeof dueDate === "string" ? new Date(dueDate) : dueDate;
  const now = new Date();
  const diff = now.getTime() - due.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "paid":
      return "text-emerald-500 bg-emerald-500/10";
    case "pending":
      return "text-amber-500 bg-amber-500/10";
    case "overdue":
      return "text-red-500 bg-red-500/10";
    case "draft":
      return "text-slate-500 bg-slate-500/10";
    case "cancelled":
      return "text-slate-400 bg-slate-400/10";
    default:
      return "text-slate-500 bg-slate-500/10";
  }
}

export function getStatusLabel(status: string): string {
  switch (status) {
    case "paid":
      return "Paid";
    case "pending":
      return "Pending";
    case "overdue":
      return "Overdue";
    case "draft":
      return "Draft";
    case "cancelled":
      return "Cancelled";
    case "sent":
      return "Sent";
    default:
      return status;
  }
}

export const debounce = <T extends (...args: any[]) => void>(fn: T, delay: number) => {
  let timeoutId: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), delay);
  };
};
