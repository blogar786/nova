export interface Business {
  id: string;
  userId: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  website?: string;
  taxNumber?: string;
  vatNumber?: string;
  gstNumber?: string;
  logoUrl?: string;
  currency: string;
  country?: string;
  template: string;
  brandColor: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Customer {
  id: string;
  userId: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  billingAddress?: string;
  shippingAddress?: string;
  taxNumber?: string;
  vatNumber?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface InvoiceItem {
  id?: string;
  description: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
  taxAmount: number;
  discount: number;
  total: number;
  lineNumber?: number;
}

export interface Invoice {
  id: string;
  userId: string;
  businessId?: string;
  customerId?: string;
  invoiceNumber: string;
  status: "draft" | "sent" | "paid" | "overdue" | "cancelled" | "pending";
  currency: string;
  issueDate: Date;
  dueDate: Date;
  purchaseOrderNumber?: string;
  referenceNumber?: string;
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  shippingAmount: number;
  totalAmount: number;
  taxType: string;
  taxRate: number;
  paymentTerms: string;
  paymentMethod?: string;
  paymentLink?: string;
  notes?: string;
  terms?: string;
  fieldConfig?: Record<string, boolean>;
  template: string;
  aiGenerated: boolean;
  aiPrompt?: string;
  errors?: any[];
  createdAt: Date;
  updatedAt: Date;
  items?: InvoiceItem[];
  business?: Business;
  customer?: Customer;
}

export interface Template {
  id: string;
  name: string;
  category: string;
  style: string;
  previewImage?: string;
  config?: any;
  isPremium: boolean;
  country?: string;
  createdAt?: Date;
}

export interface Country {
  code: string;
  name: string;
  currency: string;
  currencySymbol: string;
  taxType: string;
  taxRate: number;
  flag: string;
}

export interface FieldToggle {
  key: string;
  label: string;
  description: string;
  category: string;
  defaultOn: boolean;
}

export interface AIError {
  type: "calculation" | "duplicate" | "missing" | "invalid" | "formatting" | "legal";
  severity: "low" | "medium" | "high";
  field: string;
  message: string;
  suggestion: string;
}

export interface AnalyticsData {
  monthlyIncome: { month: string; amount: number }[];
  taxSummary: { type: string; amount: number }[];
  outstandingBalance: number;
  customerActivity: { name: string; count: number }[];
  revenuePrediction: { month: string; amount: number }[];
  latePaymentPrediction: number;
}
