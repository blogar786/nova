import { Template } from "@/lib/types";

export const templates: Template[] = [
  // Modern
  { id: "modern-1", name: "Modern Minimal", category: "Modern", style: "modern", isPremium: false, country: "Global", previewImage: "modern-1", config: { layout: "clean", colors: "neutral", font: "sans" } },
  { id: "modern-2", name: "Modern Bold", category: "Modern", style: "modern", isPremium: false, country: "Global", previewImage: "modern-2", config: { layout: "bold", colors: "gradient", font: "sans" } },
  { id: "modern-3", name: "Modern Corporate", category: "Modern", style: "modern", isPremium: true, country: "Global", previewImage: "modern-3", config: { layout: "corporate", colors: "blue", font: "sans" } },

  // Minimal
  { id: "minimal-1", name: "Minimalist", category: "Minimal", style: "minimal", isPremium: false, country: "Global", previewImage: "minimal-1", config: { layout: "minimal", colors: "neutral", font: "serif" } },
  { id: "minimal-2", name: "Swiss Minimal", category: "Minimal", style: "minimal", isPremium: false, country: "CH", previewImage: "minimal-2", config: { layout: "swiss", colors: "red", font: "sans" } },
  { id: "minimal-3", name: "Scandinavian", category: "Minimal", style: "minimal", isPremium: true, country: "SE", previewImage: "minimal-3", config: { layout: "scandinavian", colors: "pastel", font: "sans" } },

  // Corporate
  { id: "corporate-1", name: "Corporate Blue", category: "Corporate", style: "corporate", isPremium: false, country: "Global", previewImage: "corporate-1", config: { layout: "corporate", colors: "blue", font: "sans" } },
  { id: "corporate-2", name: "Corporate Dark", category: "Corporate", style: "corporate", isPremium: false, country: "Global", previewImage: "corporate-2", config: { layout: "dark", colors: "dark", font: "sans" } },
  { id: "corporate-3", name: "Executive", category: "Corporate", style: "corporate", isPremium: true, country: "Global", previewImage: "corporate-3", config: { layout: "executive", colors: "gold", font: "serif" } },

  // Luxury
  { id: "luxury-1", name: "Luxury Gold", category: "Luxury", style: "luxury", isPremium: true, country: "Global", previewImage: "luxury-1", config: { layout: "luxury", colors: "gold", font: "serif" } },
  { id: "luxury-2", name: "Luxury Black", category: "Luxury", style: "luxury", isPremium: true, country: "Global", previewImage: "luxury-2", config: { layout: "luxury", colors: "black", font: "serif" } },
  { id: "luxury-3", name: "Luxury Silk", category: "Luxury", style: "luxury", isPremium: true, country: "JP", previewImage: "luxury-3", config: { layout: "silk", colors: "cream", font: "serif" } },

  // Creative
  { id: "creative-1", name: "Creative Splash", category: "Creative", style: "creative", isPremium: false, country: "Global", previewImage: "creative-1", config: { layout: "creative", colors: "gradient", font: "display" } },
  { id: "creative-2", name: "Creative Watercolor", category: "Creative", style: "creative", isPremium: true, country: "Global", previewImage: "creative-2", config: { layout: "watercolor", colors: "pastel", font: "display" } },
  { id: "creative-3", name: "Creative Neon", category: "Creative", style: "creative", isPremium: true, country: "Global", previewImage: "creative-3", config: { layout: "neon", colors: "neon", font: "display" } },

  // Medical
  { id: "medical-1", name: "Medical Clean", category: "Medical", style: "medical", isPremium: false, country: "Global", previewImage: "medical-1", config: { layout: "clean", colors: "blue", font: "sans" } },
  { id: "medical-2", name: "Medical Professional", category: "Medical", style: "medical", isPremium: true, country: "Global", previewImage: "medical-2", config: { layout: "professional", colors: "teal", font: "sans" } },

  // Legal
  { id: "legal-1", name: "Legal Formal", category: "Legal", style: "legal", isPremium: false, country: "Global", previewImage: "legal-1", config: { layout: "formal", colors: "navy", font: "serif" } },
  { id: "legal-2", name: "Legal Traditional", category: "Legal", style: "legal", isPremium: true, country: "US", previewImage: "legal-2", config: { layout: "traditional", colors: "navy", font: "serif" } },

  // Freelancer
  { id: "freelancer-1", name: "Freelancer Modern", category: "Freelancer", style: "freelancer", isPremium: false, country: "Global", previewImage: "freelancer-1", config: { layout: "modern", colors: "purple", font: "sans" } },
  { id: "freelancer-2", name: "Freelancer Portfolio", category: "Freelancer", style: "freelancer", isPremium: true, country: "Global", previewImage: "freelancer-2", config: { layout: "portfolio", colors: "gradient", font: "display" } },

  // Construction
  { id: "construction-1", name: "Construction", category: "Construction", style: "construction", isPremium: false, country: "Global", previewImage: "construction-1", config: { layout: "industrial", colors: "orange", font: "sans" } },

  // Restaurant
  { id: "restaurant-1", name: "Restaurant", category: "Restaurant", style: "restaurant", isPremium: false, country: "Global", previewImage: "restaurant-1", config: { layout: "warm", colors: "amber", font: "display" } },

  // Hotel
  { id: "hotel-1", name: "Hotel", category: "Hotel", style: "hotel", isPremium: false, country: "Global", previewImage: "hotel-1", config: { layout: "elegant", colors: "gold", font: "serif" } },

  // Agency
  { id: "agency-1", name: "Digital Agency", category: "Agency", style: "agency", isPremium: false, country: "Global", previewImage: "agency-1", config: { layout: "modern", colors: "purple", font: "sans" } },
  { id: "agency-2", name: "Creative Agency", category: "Agency", style: "agency", isPremium: true, country: "Global", previewImage: "agency-2", config: { layout: "creative", colors: "gradient", font: "display" } },

  // Consulting
  { id: "consulting-1", name: "Consulting", category: "Consulting", style: "consulting", isPremium: false, country: "Global", previewImage: "consulting-1", config: { layout: "professional", colors: "navy", font: "sans" } },

  // Software
  { id: "software-1", name: "SaaS", category: "Software", style: "software", isPremium: false, country: "Global", previewImage: "software-1", config: { layout: "modern", colors: "blue", font: "mono" } },

  // Digital Marketing
  { id: "marketing-1", name: "Digital Marketing", category: "Digital Marketing", style: "marketing", isPremium: false, country: "Global", previewImage: "marketing-1", config: { layout: "bold", colors: "red", font: "sans" } },

  // Retail
  { id: "retail-1", name: "Retail", category: "Retail", style: "retail", isPremium: false, country: "Global", previewImage: "retail-1", config: { layout: "colorful", colors: "rainbow", font: "sans" } },

  // Wholesale
  { id: "wholesale-1", name: "Wholesale", category: "Wholesale", style: "wholesale", isPremium: false, country: "Global", previewImage: "wholesale-1", config: { layout: "industrial", colors: "gray", font: "sans" } },

  // Healthcare
  { id: "healthcare-1", name: "Healthcare", category: "Healthcare", style: "healthcare", isPremium: false, country: "Global", previewImage: "healthcare-1", config: { layout: "clean", colors: "green", font: "sans" } },

  // Education
  { id: "education-1", name: "Education", category: "Education", style: "education", isPremium: false, country: "Global", previewImage: "education-1", config: { layout: "academic", colors: "blue", font: "serif" } },

  // Beauty Salon
  { id: "beauty-1", name: "Beauty Salon", category: "Beauty Salon", style: "beauty", isPremium: false, country: "Global", previewImage: "beauty-1", config: { layout: "elegant", colors: "pink", font: "display" } },

  // Gym
  { id: "gym-1", name: "Gym & Fitness", category: "Gym", style: "gym", isPremium: false, country: "Global", previewImage: "gym-1", config: { layout: "bold", colors: "orange", font: "sans" } },

  // Automotive
  { id: "automotive-1", name: "Automotive", category: "Automotive", style: "automotive", isPremium: false, country: "Global", previewImage: "automotive-1", config: { layout: "industrial", colors: "red", font: "sans" } },

  // Fashion
  { id: "fashion-1", name: "Fashion", category: "Fashion", style: "fashion", isPremium: false, country: "Global", previewImage: "fashion-1", config: { layout: "elegant", colors: "black", font: "display" } },
  { id: "fashion-2", name: "Luxury Fashion", category: "Fashion", style: "fashion", isPremium: true, country: "Global", previewImage: "fashion-2", config: { layout: "luxury", colors: "gold", font: "serif" } },

  // Manufacturing
  { id: "manufacturing-1", name: "Manufacturing", category: "Manufacturing", style: "manufacturing", isPremium: false, country: "Global", previewImage: "manufacturing-1", config: { layout: "industrial", colors: "gray", font: "sans" } },

  // Real Estate
  { id: "realestate-1", name: "Real Estate", category: "Real Estate", style: "realestate", isPremium: false, country: "Global", previewImage: "realestate-1", config: { layout: "professional", colors: "blue", font: "serif" } },

  // Photography
  { id: "photography-1", name: "Photography", category: "Photography", style: "photography", isPremium: false, country: "Global", previewImage: "photography-1", config: { layout: "minimal", colors: "black", font: "sans" } },

  // Architecture
  { id: "architecture-1", name: "Architecture", category: "Architecture", style: "architecture", isPremium: false, country: "Global", previewImage: "architecture-1", config: { layout: "minimal", colors: "gray", font: "serif" } },

  // Import Export
  { id: "importexport-1", name: "Import Export", category: "Import Export", style: "importexport", isPremium: false, country: "Global", previewImage: "importexport-1", config: { layout: "international", colors: "blue", font: "sans" } },

  // NGO
  { id: "ngo-1", name: "NGO", category: "NGO", style: "ngo", isPremium: false, country: "Global", previewImage: "ngo-1", config: { layout: "clean", colors: "green", font: "sans" } },

  // Government
  { id: "government-1", name: "Government", category: "Government", style: "government", isPremium: false, country: "Global", previewImage: "government-1", config: { layout: "formal", colors: "navy", font: "serif" } },

  // Transportation
  { id: "transportation-1", name: "Transportation", category: "Transportation", style: "transportation", isPremium: false, country: "Global", previewImage: "transportation-1", config: { layout: "industrial", colors: "blue", font: "sans" } },

  // Logistics
  { id: "logistics-1", name: "Logistics", category: "Logistics", style: "logistics", isPremium: false, country: "Global", previewImage: "logistics-1", config: { layout: "modern", colors: "orange", font: "sans" } },

  // Cleaning
  { id: "cleaning-1", name: "Cleaning Service", category: "Cleaning", style: "cleaning", isPremium: false, country: "Global", previewImage: "cleaning-1", config: { layout: "clean", colors: "green", font: "sans" } },

  // Events
  { id: "events-1", name: "Event Planning", category: "Events", style: "events", isPremium: false, country: "Global", previewImage: "events-1", config: { layout: "elegant", colors: "purple", font: "display" } },

  // E-commerce
  { id: "ecommerce-1", name: "E-commerce", category: "E-commerce", style: "ecommerce", isPremium: false, country: "Global", previewImage: "ecommerce-1", config: { layout: "modern", colors: "blue", font: "sans" } },

  // Dropshipping
  { id: "dropshipping-1", name: "Dropshipping", category: "Dropshipping", style: "dropshipping", isPremium: false, country: "Global", previewImage: "dropshipping-1", config: { layout: "modern", colors: "orange", font: "sans" } },

  // Subscription
  { id: "subscription-1", name: "Subscription", category: "Subscription", style: "subscription", isPremium: false, country: "Global", previewImage: "subscription-1", config: { layout: "clean", colors: "blue", font: "sans" } },

  // Crypto
  { id: "crypto-1", name: "Crypto", category: "Crypto", style: "crypto", isPremium: false, country: "Global", previewImage: "crypto-1", config: { layout: "modern", colors: "purple", font: "mono" } },
  { id: "crypto-2", name: "Crypto Premium", category: "Crypto", style: "crypto", isPremium: true, country: "Global", previewImage: "crypto-2", config: { layout: "luxury", colors: "gold", font: "mono" } },

  // Startup
  { id: "startup-1", name: "Startup", category: "Startup", style: "startup", isPremium: false, country: "Global", previewImage: "startup-1", config: { layout: "modern", colors: "gradient", font: "sans" } },

  // Enterprise
  { id: "enterprise-1", name: "Enterprise", category: "Enterprise", style: "enterprise", isPremium: true, country: "Global", previewImage: "enterprise-1", config: { layout: "corporate", colors: "navy", font: "sans" } },

  // Country-specific templates
  { id: "usa-1", name: "USA Invoice", category: "Country", style: "corporate", isPremium: false, country: "US", previewImage: "usa-1", config: { layout: "us-standard", colors: "blue", font: "sans" } },
  { id: "uk-1", name: "UK Invoice", category: "Country", style: "corporate", isPremium: false, country: "GB", previewImage: "uk-1", config: { layout: "uk-standard", colors: "navy", font: "serif" } },
  { id: "germany-1", name: "Germany Invoice", category: "Country", style: "corporate", isPremium: false, country: "DE", previewImage: "germany-1", config: { layout: "de-standard", colors: "black", font: "sans" } },
  { id: "france-1", name: "France Invoice", category: "Country", style: "corporate", isPremium: false, country: "FR", previewImage: "france-1", config: { layout: "fr-standard", colors: "blue", font: "sans" } },
  { id: "japan-1", name: "Japan Invoice", category: "Country", style: "corporate", isPremium: false, country: "JP", previewImage: "japan-1", config: { layout: "jp-standard", colors: "red", font: "serif" } },
  { id: "india-1", name: "India Invoice", category: "Country", style: "corporate", isPremium: false, country: "IN", previewImage: "india-1", config: { layout: "in-standard", colors: "orange", font: "sans" } },
  { id: "uae-1", name: "UAE Invoice", category: "Country", style: "corporate", isPremium: false, country: "AE", previewImage: "uae-1", config: { layout: "uae-standard", colors: "green", font: "sans" } },
  { id: "china-1", name: "China Invoice", category: "Country", style: "corporate", isPremium: false, country: "CN", previewImage: "china-1", config: { layout: "cn-standard", colors: "red", font: "serif" } },
  { id: "brazil-1", name: "Brazil Invoice", category: "Country", style: "corporate", isPremium: false, country: "BR", previewImage: "brazil-1", config: { layout: "br-standard", colors: "green", font: "sans" } },
  { id: "saudi-1", name: "Saudi Arabia Invoice", category: "Country", style: "corporate", isPremium: false, country: "SA", previewImage: "saudi-1", config: { layout: "sa-standard", colors: "green", font: "sans" } },
];

export const templateCategories = [
  "Modern", "Minimal", "Corporate", "Luxury", "Creative",
  "Medical", "Legal", "Freelancer", "Construction", "Restaurant",
  "Hotel", "Agency", "Consulting", "Software", "Digital Marketing",
  "Retail", "Wholesale", "Healthcare", "Education", "Beauty Salon",
  "Gym", "Automotive", "Fashion", "Manufacturing", "Real Estate",
  "Photography", "Architecture", "Import Export", "NGO", "Government",
  "Transportation", "Logistics", "Cleaning", "Events", "E-commerce",
  "Dropshipping", "Subscription", "Crypto", "Startup", "Enterprise",
  "Country",
];
